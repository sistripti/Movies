<?php 
include "/opt/lampp/htdocs/Soham/SarikaHomeAppliances/anthiaflower/front/include/header.php"; 
include BASE_PATH.'include/connect.php'; 
?> 
<!--content start-->
<div class="container">

  <div class="row">
    <div class="span12">
     <div class="middle_content">
      <div class="row">

       <div class="span3">
         <div class="side-menu">
          <div class="side-menu-title">
            <h3>Product Categories
              <div class="side-menu-spach"></div>
            </h3>
          </div>
          <div id="menusidebar">
            <ul>
              <li><a href="#">Shop By Type</a></li>
              <li><a href="#">Price</a></li>
              <li><a href="#">Gifts Collection</a></li>
              <li><a href="#">Birthdays</a></li>
              <li><a href="#">Specialities</a></li>         
            </ul>
          </div>
          <div class="clr"></div>
        </div>
        <div class="special_min">
         <div class="spec_title">Specials</div>
         <div class="specl_box">
           <div class="spec_img"><img src="images/bestseller1.jpg" alt="Special img" width="80" /></div>
           <div class="spec_sub_title"><a href="#">Raspberry Orchid</a></div>
           <div class="spec_price">$100<span>$150</span></div>
           <div class="clr"></div>
         </div>
         <div class="specl_box">
           <div class="spec_img"><img src="images/bestseller1.jpg" alt="Special img" width="80" /></div>
           <div class="spec_sub_title"><a href="#">Raspberry Orchid</a></div>
           <div class="spec_price">$100<span>$150</span></div>
           <div class="clr"></div>
         </div>
         <div class="specl_box">
           <div class="spec_img"><img src="images/bestseller1.jpg" alt="Special img" width="80" /></div>
           <div class="spec_sub_title"><a href="#">Raspberry Orchid</a></div>
           <div class="spec_price">$100<span>$150</span></div>
           <div class="clr"></div>
         </div>

       </div>
       <div class="special_min">
         <div class="spec_title">Bestsellers</div>
         <div class="raspberry_orchid_bx">
          <img src="images/raspberry_orchid.jpg" alt="raspberry orchid" />
          <div class="raspberry_titl"><a href="#">Raspberry Orchid</a></div>
          <div class="raspberry_price">34.99 AED</div>
        </div>
      </div>
    </div>


    <div class="span9">

      <div class="login_head"><span><i class="fa fa-lock"></i></span> create an account</div>

      <div class="jubilane_account"><span>NOTE:</span> If you already have an account with us, please login at the <a href="#">login page.</a></div>
      <div><?php if(isset($_SESSION['success'])) { ?>
    
                                 <span style="color:green;"><?php echo $_SESSION['success']; ?></span>
    
                                 <?php unset($_SESSION['success']); } else if(isset($_SESSION['error'])){ ?>
    
                                 <span style="color:red;"><?php echo $_SESSION['error']; ?></span>
    
                                 <?php unset($_SESSION['error']); } ?></div>

      <form action="registration_store.php" method="post">

        <div class="account_bx">
          <div class="return_head">Your Personal Details</div>

          <div class="user_one">
            <div class="row">
              <div class="span2">
                <div class="email_txt"><span>*</span> First Name :</div>
              </div>
              <div class="span4">
                <div class="a"><input name="First_Name" id="First_Name" type="text" class="input_email_erro" /></div>
                <div class="erro_frm">This is a required field</div>
              </div>
            </div>
          </div>
          <div class="user_one">
            <div class="row">
              <div class="span2">
                <div class="email_txt"><span>*</span> Last Name :</div>
              </div>
              <div class="span4">
                <div class="a"><input name="Last_Name" id="Last_Name" type="text" class="input_email" /></div>
              </div>
            </div>
          </div>                                
          <div class="user_one">
            <div class="row">
              <div class="span2">
                <div class="email_txt"><span>*</span> Email Address :</div>
              </div>
              <div class="span4">
                <div class="a"><input name="Email_Id"  id="Email_Id" type="text" class="input_email" /></div>
              </div>
            </div>
          </div>
          <div class="user_one">
            <div class="row">
              <div class="span2">
                <div class="email_txt"><span>*</span> Confirm Email Address :</div>
              </div>
              <div class="span4">
                <div class="a"><input name="Confirm_Email_Id" id="Confirm_Email_Id" type="text" class="input_email" /></div>
              </div>
            </div>
          </div>

          <div class="user_one">
            <div class="row">
              <div class="span2">
                <div class="email_txt"><span>*</span> Password :</div>
              </div>
              <div class="span4">
                <div class="a"><input name="Password" id="Password" type="text" class="input_email" /></div>
              </div>
            </div>
          </div>
          <div class="user_one">
            <div class="row">
              <div class="span2">
                <div class="email_txt"><span>*</span> Confirm Password :</div>
              </div>
              <div class="span4">
                <div class="a"><input name="Confirm_Password" id="Confirm_Password" type="text" class="input_email" /></div>
              </div>
            </div>
          </div>

          <div class="cont_bt"><center><input type="submit" name="Signup" id="Signup" value="Signup"></center></div>

        </div> 
      </form>
    </div>


  </div>
</div>
</div>
</div>
</div>
<!-- content end--> 

<?php include BASE_PATH."include/footer.php" ?>

</body>
</html>
