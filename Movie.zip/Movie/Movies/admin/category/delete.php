<?php
session_start();
include "/opt/lampp/htdocs/Tripti/Movies/Moviesdata/admin/include/connect.php";
if(isset($_GET['id'])){

	$sql="DELETE FROM `tbl_category` WHERE `id`=".base64_decode($_GET['id'])."";

	if(mysqli_query($conn,$sql)){
         $_SESSION['success'] = "Record deleted successfully";
         header('Refresh: 0; url=manage.php');
	}
	else{
		$_SESSION['error'] = "Something went wrong";
        header('Refresh: 0; url=manage.php');
	}

}
else{
	$_SESSION['error'] = "Something went wrong";
    header('Refresh: 0; url=manage.php');
}

?>
