<?php 
include "/opt/lampp/htdocs/Soham/SarikaHomeAppliances/anthiaflower/front/include/connect.php";
session_start();
if(isset($_SESSION["email_id"]) && isset($_SESSION["password"]) && isset($_SESSION["user_id"]) && isset($_SESSION["first_name"]) && isset($_SESSION["last_name"]))
{
    $_SESSION['error'] = "you are already logged in please logout the current session";
    header('Refresh: 0; url=index.php'); 
}
else
{
if(isset($_POST['Signin']))
{
   $_SESSION['email_id'] = $_POST['lgn_Email_Id'];
   $_SESSION['password'] = $_POST['lgn_Password'];

   if(!isset($_POST['lgn_Email_Id']) || $_POST['lgn_Email_Id'] =="")
   { 
      $_SESSION['error'] = "Please enter email";
      header('Refresh: 0; url=user_login.php'); 
   } 
   else if(!isset($_POST['lgn_Password']) || $_POST['lgn_Password'] =="") 
   { 
      $_SESSION['error'] = "Please enter password";
      header('Refresh: 0; url=user_login.php'); 
   } 
   $email_id    = $_POST['lgn_Email_Id'];
   $password = $_POST['lgn_Password']; 

   /* sql query */
   $sql = "SELECT `id`, `first_name`, `last_name`, `email_id`
           FROM `tbl_user_registration` 
           WHERE `email_id` = '".$email_id."' AND `password` = '".$password."'";
   
   $res  = mysqli_query($conn,$sql);
   $rows = mysqli_fetch_array($res);

   $sql_checkout = "SELECT * FROM `tbl_cart` WHERE `user_id` = '".$_SESSION["user_id"]."'";
   $res_chcekout = mysqli_query($conn,$sql_checkout);

   if(count($rows) > 0){
    $_SESSION['user_id']          = $rows['id'];
    $_SESSION['first_name']  = $rows['first_name'];
    $_SESSION['last_name']   = $rows['last_name'];
    $_SESSION['email_id']    = $rows['email_id'];
    $flag = 0;
    while ($rows_checkout = mysqli_fetch_array($res_chcekout)) {
        
      if ($rows_checkout["checkout"] == "NO") {
                    $flag = 1;
      }
      else
      {
        $flag = 0;
      }

    }
    if ($flag == 1) {
      # code...
    echo $flag;    
    $_SESSION['success']    = "Login successfully";
    header('Refresh: 5; url=index.php');  
   }
   else
   {  echo $flag;
      $_SESSION['success']  = "Proceed to checkout your items.";
    header('Refresh: 5 url=checkout.php');  
   }
 }
   else{
     $_SESSION['error'] = "Please enter valid credentials";
     header('Refresh: 0; url=user_login.php'); 
   
   }
}
}   
?>