<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>Antheia Flowers ::thank_you::</title>

<!--main-css-->
<link href="css/antheia_flowers.css" rel="stylesheet" type="text/css" media="screen" />

<!--Bootstrap responsive-->
<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
<link href="css/bootstrap-responsive.min.css" rel="stylesheet" type="text/css" />

<!--font-awesome-css-start-here-->
<link href="css/font-awesome.css" rel="stylesheet" type="text/css" />
<link href="css/font-awesome.min.css" rel="stylesheet" type="text/css" />

<!--[if gte IE 8]>
	<link rel="stylesheet" type="text/css" href="css/ie8-and-up.css" />
<![endif]-->

<!--main-menu-->
<link href="css/main.css" rel="stylesheet" type="text/css" />
<link href="css/demo.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" language="javascript" src="js/jquery-1.8.2.js"></script> 
<script type="text/javascript" language="javascript" src="js/flaunt.js"></script>


</head>

<body>

<!--top bar start-->
<div class="top_bar_head">
  <div class="container">
    <div class="row">
      <div class="span12">
        <div class="row">
          <div class="span10">
            <div class="top_list">
              <ul>
                <li><a href="#"><i class="fa fa-user"></i>My Account</a></li>
                <li><a href="#"><i class="fa fa-heart"></i>My Wishlist</a></li>
                <li><a href="#"><i class="fa fa-check"></i>Checkout</a></li>
                <li><a href="#"><i class="fa fa-lock"></i>Log in</a></li>
              </ul>
            </div>
          </div>
          <div class="span2">
            <div class="top_item_bx"><img src="images/item.png" alt="item" /><a href="#">0 item(s)</a></div>
            
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!--top bar end-->





<!--logo bar start-->
<div class="logo_bar_head">
  <div class="container">
    <div class="row">
      <div class="span12">
      
      <div class="row">
      <div class="span3"><div class="logo"><img src="images/logo.jpg" alt="logo" /></div></div>
      <div class="span7"><div class="free_delivery"><a href="#"><img src="images/free_delivery.jpg" alt="free_delivery" /></a></div>
      <div class="serch_bx">
      <form class="custom" method="get" id="ajax_searchform" action="sweetdatewp">
            <div class="search_l"><input type="text" value="" name="s" class="search_menu" placeholder="Enter your keyword..." /></div>
            <div class="search_button"><button class="search_bt" id="search"><img src="images/search.png" alt="search" /></button></div>  
    </form></div>
      </div>
      <div class="span2">
      <div class="top_socila">
      <ul>
      <li><a href="#"><img src="images/facebook.jpg" alt="facebook" /></a></li>
      <li><a href="#"><img src="images/twitter.jpg" alt="twitter" /></a></li>
      <li><a href="#"><img src="images/google.jpg" alt="google" /></a></li>
      <li><a href="#"><img src="images/in.jpg" alt="in" /></a></li>
      </ul>
      </div>
      </div>
      </div>
      
      </div>
    </div>
  </div>
</div>
<!--top bar end--> 

<!--main menu start--> 
<div class="menu_head">
<div class="container">
<div class="row">
<div class="span12">
        	<div class="nav">                                                                                    
							<ul class="nav-list">
                            <li class="nav-item"><a href="#" class="act">Home</a></li>
                            <li class="nav-item"><a href="#">Shop By Type</a>
                            <ul class="nav-submenu">
								<li class="nav-submenu-item">
									<a href="?=submenu-1">The Institution</a>
								</li>
								<li class="nav-submenu-item">
									<a href="?=submenu-2">NMC Activities</a>
								</li>
								<li class="nav-submenu-item">
									<a href="?=submenu-3">Board Members</a>
								</li>
								<li class="nav-submenu-item">
									<a href="?=submenu-4">Advisory Board4</a>
								</li>
                                <li class="nav-submenu-item">
									<a href="?=submenu-5">Teachers</a>
								</li>
							</ul>
                            </li>
                            <li class="nav-item"><a href="#">Price</a></li>
                            <li class="nav-item"><a href="#">Occasions</a></li>
                            <li class="nav-item"><a href="#">Gifts Collection</a></li>
                            <li class="nav-item"><a href="#">Birthdays</a></li>
                            <li class="nav-item"><a href="#">Specialities</a></li>
                            <li class="nav-item"><a href="#">Blogs</a></li>
                            <li class="nav-item"><a href="#" class="last">Contact Us</a></li>
							</ul>
			</div>
</div>
</div>
</div>
</div>
<!-- main menu end--> 



<!--content start-->
<div class="container">

<div class="row">
<div class="span12">
	<div class="middle_content">
    
    		<div class="head_area">
                        <div class="related_prod">Thank You </div>
                        <div class="prod_bor"></div>
                    </div>
                    
            
            <div class="row">
                	<div class="span3"><div class="thankyou_pic"><img src="images/Thank_you.png" alt="Thank_you" /></div></div>
                    <div class="span9">
                    	<div class="about_bx">
                        	<span>Thank You For Registration</span>
                            <p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>
                            
                            <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.</p>
                            
                        </div>
                    </div>
                </div>
                
                    
                    
                    
        
	</div>
</div>
</div>
</div>
<!-- content end--> 




<!--footer start-->
<div class="footer_links">
	<div class="container">
    	<div class="row">
        	<div class="span12">
            	<div class="row">
                	<div class="span3">
                    	<div class="footer_heading">About US</div>
                        <div class="heading_bor"></div>
                        <div class="menu_name">
                        	<ul>
                            	<li><a href="#"><i class="fa fa-caret-right"></i>About Us</a></li>
                                <li><a href="#"><i class="fa fa-caret-right"></i>Antheia Flowers Stories</a></li>
                                <li><a href="#"><i class="fa fa-caret-right"></i>Our Press</a></li>
                                <li><a href="#"><i class="fa fa-caret-right"></i>Terms &amp; Conditions</a></li>
                                <li><a href="#"><i class="fa fa-caret-right"></i>Privacy Policy</a></li>
                                <li><a href="#"><i class="fa fa-caret-right"></i>Sitemap</a></li>
                            </ul>
                        </div>
                    </div>
                    
                    <div class="span3">
                    	<div class="footer_heading">Customer Service</div>
                        <div class="heading_bor"></div>
                        <div class="menu_name">
                        	<ul>
                            	<li><a href="#"><i class="fa fa-caret-right"></i>Contact Us</a></li>
                                <li><a href="#"><i class="fa fa-caret-right"></i>Customer service</a></li>
                                <li><a href="#"><i class="fa fa-caret-right"></i>Privacy policy</a></li>
                                <li><a href="#"><i class="fa fa-caret-right"></i>FAQ's</a></li>
                                <li><a href="#"><i class="fa fa-caret-right"></i>My Account (Log In)</a></li>
                            </ul>
                        </div>
                    </div>
                    
                    <div class="span3">
                    	<div class="footer_heading">Our Products</div>
                        <div class="heading_bor"></div>
                        <div class="menu_name">
                        	<ul>
                            	<li><a href="#"><i class="fa fa-caret-right"></i>How to apply &amp; Tips</a></li>
                                <li><a href="#"><i class="fa fa-caret-right"></i>Sample Request</a></li>
                                <li><a href="#"><i class="fa fa-caret-right"></i>Product Features</a></li>
                                <li><a href="#"><i class="fa fa-caret-right"></i>Customer Stories</a></li>
                            </ul>
                        </div>
                    </div>
                    
                    <div class="span3">
                    	<div class="footer_heading">Newsletter Sing Up</div>
                        <div class="heading_bor"></div>
                        <div class="menu_name">
                        	<input name="" type="text" class="frm_newsletter" placeholder="Enter your E-mail address " />
                            <div class="bt_newsletter"><input name="" type="button" value="Subscribe" class="btn_news" /></div>
                            <div class="footer_social">
                            <ul>
                            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                            <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                            </ul>
                            </div>
                        </div>
                    </div>
                    
                    
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Footer end--> 

<div class="footer_copyright">
	<div class="container">
    	<div class="row">
        	<div class="span12">
            <div class="footer_copy_main">
            	<div class="copyright_l">&copy; 2015 Antheia Flowers Ltd. All Rights Reserved.</div>
                <div class="copyright_r">
                	<ul>
                    	<li>We Accept These Cards :</li>
                    	<li><a href="#"><img src="images/payment_1.jpg" alt="payment_1" /></a></li>
                        <li><a href="#"><img src="images/payment_2.jpg" alt="payment_2" /></a></li>
                        <li><a href="#"><img src="images/payment_3.jpg" alt="payment_3" /></a></li>
                        <li><a href="#"><img src="images/payment_4.jpg" alt="payment_4" /></a></li>
                        <li><a href="#"><img src="images/payment_5.jpg" alt="payment_5" /></a></li>
                    </ul>
        </div>
        	</div>
                <div class="clr"></div>
            </div>
        </div>
    </div>
</div>




<!-- Bootstrap responsive --> 
<script type="text/javascript" language="javascript" src="js/bootstrap.min.js"></script> 
<!-- Bootstrap responsive -->
</body>
</html>
