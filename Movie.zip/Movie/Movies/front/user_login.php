<?php 
include "/opt/lampp/htdocs/Soham/SarikaHomeAppliances/anthiaflower/front/include/header.php"; 
include BASE_PATH.'include/connect.php'; 
?> 

<!--content start-->
<div class="container">

  <div class="row">
    <div class="span12">
     <div class="middle_content">
      <div class="row">

       <div class="span3">
         <div class="side-menu">
          <div class="side-menu-title">
            <h3>Product Categories
              <div class="side-menu-spach"></div>
            </h3>
          </div>
          <div id="menusidebar">
            <ul>
              <li><a href="#">Shop By Type</a></li>
              <li><a href="#">Price</a></li>
              <li><a href="#">Gifts Collection</a></li>
              <li><a href="#">Birthdays</a></li>
              <li><a href="#">Specialities</a></li>



            </ul>
          </div>
          <div class="clr"></div>
        </div>	
      </div>

      <div class="span9">

        <div class="login_head"><span><i class="fa fa-lock"></i></span> Sign in or create an account</div>

        <div class="row">
         <div class="span3">
           <div class="return_head">CREATE A NEW ACCOUNT</div>
           <div class="jubilane_account">I'm a New Cusomer </div>

           <div class="account_points">
             <ul>
               <li>Check out faster</li>
               <li>Save multiple shipping addresses</li>
               <li>Access your order history</li>
               <li>Track new orders</li>
               <li>Save items to your wish list</li>
             </ul>
           </div>


           <div class="cont_bt"><a href="#">Continue <i class="fa fa-caret-right"></i></a></div>
         </div>
         <div class="span1"><div class="login_seprator"></div></div>
         <div class="span5">
           <div class="return_head">SIGN IN TO YOUR ACCOUNT</div>
           <div class="jubilane_account">Please login to your Jubilane account</div>
           <div><?php if(isset($_SESSION['success'])) { ?>

             <span style="color:green;"><?php echo $_SESSION['success']; ?></span>

             <?php unset($_SESSION['success']); } else if(isset($_SESSION['error'])){ ?>

               <span style="color:red;"><?php echo $_SESSION['error']; ?></span>

               <?php unset($_SESSION['error']); } ?></div>
               <form action="login_check.php" method="post">
                 <div class="user_one">
                   <div class="row">
                     <div class="span2">
                       <div class="email_txt"><span>*</span> Email Address :</div>
                     </div>
                     <div class="span3">
                      <div class="a"><input name="lgn_Email_Id" id="lgn_Email_Id" type="text" class="input_email" /></div>
                    </div>
                  </div>
                </div>

                <div class="user_one">
                 <div class="row">
                   <div class="span2">
                     <div class="email_txt"><span>*</span> Password :</div>
                   </div>
                   <div class="span3">
                     <div class="a"><input name="lgn_Password" id="lgn_Password" type="password" class="input_email" /></div>
                   </div>
                 </div>
               </div>

               <div class="user_one">
                 <div class="row">
                   <div class="span2" style="height:1px;">

                   </div>
                   <div class="span3">
                     <div class="forgot_pass"><a href="#">Password forgotten? Click here.</a></div>
                   </div>
                 </div>
               </div>



               <div class="cont_bt"><input type="submit" name="Signin" id="Signin" value="Sign In"></div>
             </form>
           </div>                                
         </div>


       </div>

     </div>
   </div>
 </div>
</div>
</div>
<!-- content end--> 

<?php include BASE_PATH."include/footer.php" ?>


</body>
</html>
