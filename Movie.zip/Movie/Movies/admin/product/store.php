<?php
include "/opt/lampp/htdocs/Tripti/Movies/Moviesdata/admin/include/connect.php";
session_start();
if(isset($_POST['Save']))
{

	if(isset($_POST['Category_Name_Select'])){ $Category_Name_Select= $_POST['Category_Name_Select']; } else { $Category_Name_Select= ""; }
	if(isset($_POST['Sub_Category_Name_Select'])){ $Sub_Category_Name_Select= $_POST['Sub_Category_Name_Select']; } else { $Sub_Category_Name_Select= ""; }
	if(isset($_POST['Product_Name'])){ $Product_Name = $_POST['Product_Name']; } else { $Product_Name= ""; }
	if(isset($_POST['Price'])){ $Price = $_POST['Price']; } else { $Price= ""; }	
	if(isset($_FILES)){
		$Image=$_FILES["Upload_Image"]["name"];
		$uploaddir= "/opt/lampp/htdocs/Tripti/Movies/Moviesdata/admin/upload/product_img";
		$uploadfile=$uploaddir.'/'.basename($_FILES["Upload_Image"]["name"]);
		if(move_uploaded_file($_FILES["Upload_Image"]["tmp_name"],$uploadfile )){
		}
		else
		{
		}
	}

    $sql = "SELECT * FROM `tbl_product` WHERE sub_category_id='$Sub_Category_Name_Select' AND category_id='$Category_Name_Select' AND product_name='$Product_Name'";
	$res  = mysqli_query($conn,$sql);
	$rows = mysqli_num_rows($res);
	if($rows > 0) {
		$_SESSION['error'] = "Product exists";
        header('Refresh: 0; url=manage.php');
	} else {
		$sql ="INSERT INTO `tbl_product`( `category_id`, `sub_category_id`, `product_name`, `price`, `image`) 
		       VALUES ('".$Category_Name_Select."','".$Sub_Category_Name_Select."','".$Product_Name."','".$Price."','".$Image."')";
		$result = mysqli_query($conn, $sql) or die('Error querying database.');
		$_SESSION['success'] = "Product Added";
        header('Refresh: 0; url=manage.php');
	}
}
?>
