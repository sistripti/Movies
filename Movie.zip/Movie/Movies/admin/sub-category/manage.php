    <?php session_start(); 
include "/opt/lampp/htdocs/Tripti/Movies/Moviesdata/admin/include/connect.php";
          include BASE_PATH."include/connect.php";
?>
        <!-- BEGIN Container -->
        <div class="container" id="main-container">
            <?php include BASE_PATH."include/sidebar.php"; ?>
            <!-- BEGIN Content -->
            <div id="main-content">
                <!-- BEGIN Page Title -->
                <div class="page-title">
                    <div>
                        <h1><i class="fa fa-file-o"></i> Sub Category Manage</h1>
                        <h4>Basic table, bordered table, striped table and more</h4>
                    </div>
                </div>
                <!-- END Page Title -->

                <!-- BEGIN Breadcrumb -->
                <div id="breadcrumbs">
                    <ul class="breadcrumb">
                        <li>
                            <i class="fa fa-home"></i>
                            <a href="index.html">Home</a>
                            <span class="divider"><i class="fa fa-angle-right"></i></span>
                        </li>
                        <li class="active">Sub Category Manage</li>
                    </ul>
                </div>
                <!-- END Breadcrumb -->
                <?php if(!empty($_SESSION['success'])) { ?>
                <div class="alert alert-success">
                    <button class="close" data-dismiss="alert">&times;</button>
                    <strong>Success!</strong> <?php echo $_SESSION['success']; unset($_SESSION['success']);?>
                </div>
                <?php } ?>

                <?php if(!empty($_SESSION['error'])) {?>
                <div class="alert alert-danger">
                    <button class="close" data-dismiss="alert">&times;</button>
                    <strong>Error!</strong> <?php echo $_SESSION['error']; unset($_SESSION['error']);?>
                </div>
                <?php } ?> 
                <!-- BEGIN Main Content -->
               
                <div class="row">
                    <div class="col-md-12">
                        <div class="box">
                            <div class="box-title">
                                <h3><i class="fa fa-table"></i> Sub Categories </h3>
                                <div class="box-tool">
                                    <a data-action="collapse" href="#"><i class="fa fa-chevron-up"></i></a>
                                    <a data-action="close" href="#"><i class="fa fa-times"></i></a>
                                </div>
                            </div>
                            <div class="box-content">
                                <div class="table-responsive">
                                    <table class="table table-striped table-hover fill-head">
                                        <thead>
                                            <tr>
                                                <th>Category Name</th>
                                                <th>Sub Category Name</th>
                                                <th style="width: 150px">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php 
                                            //$sql = "SELECT * FROM `tbl_sub_category`";
                                            $sql = "SELECT 
                                                          tbl_sub_category.id, 
                                                          tbl_sub_category.sub_category_name,
                                                          tbl_category.category_name
                                                    FROM tbl_sub_category
                                                    INNER JOIN tbl_category 
                                                          ON tbl_category.id=tbl_sub_category.category_id";


                                            $res = mysqli_query($conn,$sql);
                                            while ($row = mysqli_fetch_array($res)) { ?>
                                                
                                                <tr>
                                                    <td><?php echo $row['category_name']; ?></td>
                                                    <td><?php echo $row['sub_category_name']; ?></td>
                                                    <td>
                                                        <a class="btn btn-primary btn-sm" href="edit.php?id=<?php echo base64_encode($row['id']); ?>"><i class="fa fa-edit"></i> Edit</a>
                                                        <a class="btn btn-danger btn-sm" href="delete.php?id=<?php echo base64_encode($row['id']); ?>"><i class="fa fa-trash-o"></i> Delete</a>
                                                    </td>
                                                </tr>

                                            <?php }
                                            ?>
                                                

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- END Main Content -->
                <?php include BASE_PATH."include/footer.php"; ?>
                <a id="btn-scrollup" class="btn btn-circle btn-lg" href="#"><i class="fa fa-chevron-up"></i></a>
            </div>
            <!-- END Content -->  
        </div>
        <!-- END Container -->
    </body>
</html>
