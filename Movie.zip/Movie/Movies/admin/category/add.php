   <?php session_start(); ?>
    <?php include "/opt/lampp/htdocs/Tripti/Movies/Moviesdata/admin/include/header.php"; ?>
        <!-- BEGIN Container -->
        <div class="container" id="main-container">
            <?php include BASE_PATH."include/sidebar.php"; ?>
            <!-- BEGIN Content -->
            <div id="main-content">
                <!-- BEGIN Page Title -->
                <div class="page-title">
                    <div>
                        <h1><i class="fa fa-file-o"></i> Category</h1>
                        <h4>Simple form element, griding and layout</h4>
                    </div>
                </div>
                <!-- END Page Title -->
                <!-- BEGIN Breadcrumb -->
                <div id="breadcrumbs">
                    <ul class="breadcrumb">
                        <li>
                            <i class="fa fa-home"></i>
                            <a href="<?php echo BASE_URL?>index.php">Home</a>
                            <span class="divider"><i class="fa fa-angle-right"></i></span>
                        </li>
                        <li class="active">Add Category</li>
                    </ul>
                </div>
                <!-- END Breadcrumb -->
                <!-- BEGIN Main Content -->
                <div class="row">
                    <div class="col-md-12">
                        <div class="box">
                            <div class="box-title">
                                <h3><i class="fa fa-bars"></i> Category</h3>
                                <div class="box-tool">
                                    <a data-action="collapse" href="#"><i class="fa fa-chevron-up"></i></a>
                                    <a data-action="close" href="#"><i class="fa fa-times"></i></a>
                                </div>
                            </div>
                            <div class="box-content">
                                 
                                 <?php if(isset($_SESSION['success'])) { ?>
    
                                 <span style="color:green;"><?php echo $_SESSION['success']; ?></span>
    
                                 <?php unset($_SESSION['success']); } else if(isset($_SESSION['error'])){ ?>
    
                                 <span style="color:red;"><?php echo $_SESSION['error']; ?></span>
    
                                 <?php unset($_SESSION['error']); } ?>
                                 
                                 <form action="store.php" method="post" class="form-horizontal">
                                    <div class="form-group">
                                       <label class="col-sm-3 col-lg-2 control-label">Name</label>
                                       <div class="col-sm-9 col-lg-10 controls">
                                          <input type="text" name="Category_Name" placeholder="small" class="form-control num_restrict input-sm" />
                                          <span class="help-inline error" style="color:red;"></span>
                                          <span id="err_msg_input"></span>
                                       </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2">
                                           <button type="submit" name="Save" class="btn btn-primary"><i class="fa fa-check"></i> Save</button>
                                           <button type="button" name="Cancel" class="btn">Cancel</button>
                                        </div>
                                    </div>
                                 </form>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- END Main Content -->
                <?php include BASE_PATH."include/footer.php"; ?>
                <a id="btn-scrollup" class="btn btn-circle btn-lg" href="#"><i class="fa fa-chevron-up"></i></a>
            </div>
            <!-- END Content -->
        </div>
        <!-- END Container -->

<script type="text/javascript" src="/opt/lampp/htdocs/Soham/SarikaHomeAppliances/anthiaflower/admin/js/jquery-1.11.3.min.js"></script>
    <script>        
        $(document).ready(function(){
            var flag=0;        
            $(".btn-primary").click(function(){

                var txt_Category_Name = $(".input-sm").val();

                if(txt_Category_Name=="")
                {    alert("Something went wrong!");
                     return false;
                }
                else
                {   return true;
                }

            });

            $(".num_restrict").keypress(function(event){
                        var inputValue = event.which;
                        $(this).parent().find('.wrapDiv').html('');
                        if(!(inputValue >= 65 && inputValue <= 122) && (inputValue != 32 && inputValue!=8 && inputValue != 0 && inputValue!=46 && inputValue!=44 && inputValue!=13  && inputValue!=46)) 
                        { 
                            $(this).parent().find('.error,.err').html('only character allow');
                            event.preventDefault(); 
                        }
                        else
                        {
                            $(this).parent().find('.error,.err').html('');
                        }
                });

        });


    </script>
    </body>
</html>
