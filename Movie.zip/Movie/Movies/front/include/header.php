<?php
define('BASE_URL', 'http://localhost/Soham/SarikaHomeAppliances/anthiaflower/front/'); 
define('BASE_PATH', '/opt/lampp/htdocs/Soham/SarikaHomeAppliances/anthiaflower/front/'); 
define('BASE_ADMIN_URL', 'http://localhost/Soham/SarikaHomeAppliances/anthiaflower/admin/');
include BASE_PATH."include/connect.php";
session_start(); 
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Antheia Flowers</title>

  <!--main-css-->
  <link href="<?php echo BASE_URL; ?>css/antheia_flowers.css" rel="stylesheet" type="text/css" media="screen" />

  <!--Bootstrap responsive-->
  <link href="<?php echo BASE_URL; ?>css/bootstrap.min.css" rel="stylesheet" type="text/css" />
  <link href="<?php echo BASE_URL; ?>css/bootstrap-responsive.min.css" rel="stylesheet" type="text/css" />

  <!--font-awesome-css-start-here-->
  <link href="<?php echo BASE_URL; ?>css/font-awesome.css" rel="stylesheet" type="text/css" />
  <link href="<?php echo BASE_URL; ?>css/font-awesome.min.css" rel="stylesheet" type="text/css" />

<!--[if gte IE 8]>
	<link rel="stylesheet" type="text/css" href="css/ie8-and-up.css" />
<![endif]-->

<!--main-menu-->
<link href="<?php echo BASE_URL; ?>css/main.css" rel="stylesheet" type="text/css" />
<link href="<?php echo BASE_URL; ?>css/demo.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" language="javascript" src="<?php echo BASE_URL; ?>js/jquery-1.8.2.js"></script> 
<script type="text/javascript" language="javascript" src="<?php echo BASE_URL; ?>js/flaunt.js"></script>

<!--hover effect -->
<link rel="stylesheet" href="<?php echo BASE_URL; ?>css/thirdeffect.css" type="text/css" />


<!--slider-css-js-start-here-->
<link rel="stylesheet" type="text/css" href="<?php echo BASE_URL; ?>css/slider-pro.min.css" media="screen"/>
<link rel="stylesheet" type="text/css" href="<?php echo BASE_URL; ?>css/examples.css" media="screen"/>

<!--checkbox-radio-css-->
<link rel="stylesheet" href="<?php echo BASE_URL; ?>css/style.css" type="text/css" />

<script type="text/javascript" src="<?php echo BASE_URL; ?>js/jquery.sliderPro.min.js"></script>

<link rel="stylesheet" href="<?php echo BASE_URL; ?>css/accordion.css" />

<script type="text/javascript" language="javascript" src="<?php echo BASE_URL; ?>js/script.js"></script>

<!--form-drop-arrow-->
<script type="text/javascript">
  $(document).ready(function(){ 

    if (!$.browser.opera) {
    
      // select element styling
      $('select.select').each(function(){
        var title = $(this).attr('title');
        if( $('option:selected', this).val() != ''  ) title = $('option:selected',this).text();
        $(this)
          .css({'z-index':10,'opacity':0,'-khtml-appearance':'none'})
          .after('<span class="select">' + title + '</span>')
          .change(function(){
            val = $('option:selected',this).text();
            $(this).next().text(val);
            })
      });

    };
    
  });
</script>

<!--checkbox-radio-css-->
<link rel="stylesheet" href="<?php echo BASE_URL; ?>css/style.css" type="text/css" />

<script type="text/javascript">
	$( document ).ready(function( $ ) {
		$( '#example5' ).sliderPro({
			width: 1170,
			height: 400,
			orientation: 'vertical',
			loop: false,
			arrows: true,
			buttons: false,
			thumbnailsPosition: 'right',
			thumbnailPointer: true,
			thumbnailArrows: true,
			thumbnailWidth: 273,
			thumbnailHeight: 130,
			breakpoints: {
				800: {
					thumbnailsPosition: 'bottom',
					thumbnailWidth: 190,
					thumbnailHeight: 100
				},
				640: {
					thumbnailsPosition: 'bottom',
					thumbnailWidth: 120,
					thumbnailHeight: 80
				}
			}
		});
	});


</script>

</head>

<body>

  <!--top bar start-->
  <div class="top_bar_head">
    <div class="container">
      <div class="row">
        <div class="span12">
          <div class="row">
            <div class="span10">
              <div class="top_list">
                <ul>
                  <li><a href="#"><i class="fa fa-user"></i>My Account</a></li>
                  <li><a href="#"><i class="fa fa-heart"></i>My Wishlist</a></li>
                  <li><a href="#"><i class="fa fa-check"></i>Checkout</a></li>
                  <li><a href="<?php echo BASE_URL; ?>login_check.php"><i class="fa fa-lock"></i>Log in</a></li>
                </ul>
              </div>
            </div>
            <div class="span2">
              <div class="top_item_bx"><img src="<?php echo BASE_URL; ?>images/item.png" alt="item" /><a href="#"><span name="Cart_Value" id="Cart_Value" ></span> Item(s)</a></div>
              
              <div class="top_cart_min">
                <div class="recet_item">Recently added item(s)</div>
                <div id="Cart_Box"></div>
                <div class="sub_total"><span class="item_sub">Sub-Total</span><span class="item_total">$800.00</span><div class="clr"></div></div>
                <div class="recet_item">
                  <span class="item_view"><a href="shopping_cart.php">View Cart</a></span>
                  <span class="item_chek"><a href="shopping_cart.php">Checkout</a></span>
                  <div class="clr"></div>
                </div>
                <div class="clr"></div>
              </div>
              
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!--top bar end-->

  <!--logo bar start-->
  <div class="logo_bar_head">
    <div class="container">
      <div class="row">
        <div class="span12">
          
          <div class="row">
            <div class="span3"><div class="logo"><img src="<?php echo BASE_URL;?>images/logo.jpg" alt="logo" width=100px; /></div></div>
            <div class="span7"><div class="free_delivery"><a href="#"><img src="<?php echo BASE_URL; ?>images/free_delivery.jpg" alt="free_delivery" /></a></div>
            <div><?php if(isset($_SESSION['success'])) { ?>

             <span style="color:green;"><?php echo $_SESSION['success']; ?></span>

             <?php unset($_SESSION['success']); } else if(isset($_SESSION['error'])){ ?>

               <span style="color:red;"><?php echo $_SESSION['error']; ?></span>

               <?php unset($_SESSION['error']); } ?></div>
            <div class="serch_bx">
              <form class="custom" method="get" id="ajax_searchform" action="sweetdatewp">
                <div class="search_l"><input type="text" value="" name="s" class="search_menu" placeholder="Enter your keyword..." /></div>
                <div class="search_button"><button class="search_bt" id="search"><img src="<?php echo BASE_URL; ?>images/search.png" alt="search" /></button></div>  
              </form></div>
            </div>
            <div class="span2">
              <div class="top_socila">
                <ul>
                  <li><a href="#"><img src="<?php echo BASE_URL; ?>images/facebook.jpg" alt="facebook" /></a></li>
                  <li><a href="#"><img src="<?php echo BASE_URL; ?>images/twitter.jpg" alt="twitter" /></a></li>
                  <li><a href="#"><img src="<?php echo BASE_URL; ?>images/google.jpg" alt="google" /></a></li>
                  <li><a href="#"><img src="<?php echo BASE_URL; ?>images/in.jpg" alt="in" /></a></li>
                </ul>
              </div>
            </div>
          </div>
          
        </div>
      </div>
    </div>
  </div>
  <!--top bar end--> 

  <!--main menu start--> 
  <div class="menu_head">
    <div class="container">
      <div class="row">
        <div class="span12">
        	<div class="nav">

           <ul class="nav-list">
             
            <li class="nav-item"><a href="<?php echo BASE_URL; ?>index.php" class="act">Home</a></li>

            <?php 
            
            $sql = "SELECT * FROM `tbl_category`";

            $res = mysqli_query($conn,$sql);

            while ($row = mysqli_fetch_array($res)) 

             { ?>

              <li class="nav-item"><a href="#"><?php echo $row["category_name"]; ?></a>
                
                <ul class="nav-submenu">

                  <?php 
                  $sql1 = "SELECT * FROM `tbl_sub_category` WHERE `category_id`= ".$row['id']."";

                  $res1 = mysqli_query($conn,$sql1);

                  while ($row1 = mysqli_fetch_array($res1)) { ?>
                    
                    <li class="nav-submenu-item">
                      
                     <a href="<?php echo BASE_URL; ?>product_list_view.php?id=<?php echo base64_encode($row1['id']);  ?>"><?php echo $row1["sub_category_name"]; ?></a>

                   </li>
                 <?php } ?> 
               </ul>                            
               
             </li>
           <?php } ?>
         </ul>                            
       </div>
     </div>
   </div>
 </div>
</div>
<!-- main menu end--> 
