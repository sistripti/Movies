<?php 
include "/opt/lampp/htdocs/Soham/SarikaHomeAppliances/anthiaflower/front/include/header.php"; 
include BASE_PATH.'include/connect.php'; 
?> 

<!--form-drop-arrow-->
<script type="text/javascript">
  $(document).ready(function(){ 

    if (!$.browser.opera) {
      
      // select element styling
      $('select.select').each(function(){
        var title = $(this).attr('title');
        if( $('option:selected', this).val() != ''  ) title = $('option:selected',this).text();
        $(this)
        .css({'z-index':10,'opacity':0,'-khtml-appearance':'none'})
        .after('<span class="select">' + title + '</span>')
        .change(function(){
          val = $('option:selected',this).text();
          $(this).next().text(val);
        })
      });
    };
    
  });
</script>
<!--content start-->
<div class="container">
  <div class="row">
    <div class="span12">
      <div class="middle_content">
        
        <div class="top_breadcrumb"> <a href="#">Home &nbsp;</a> /&nbsp; Product List</div>
        
        <div class="row">
          
          <div class="span3">
            <div class="side-menu">
              <div class="side-menu-title">
                <h3>Product Categories
                  <div class="side-menu-spach"></div>
                </h3>
              </div>
              <div id="menusidebar">
                <ul>
                  <li><a href="#">Shop By Type</a></li>
                  <li><a href="#">Price</a></li>
                  <li><a href="#">Gifts Collection</a></li>
                  <li><a href="#">Birthdays</a></li>
                  <li><a href="#">Specialities</a></li>
                </ul>
              </div>
              <div class="clr"></div>
            </div>
            <div class="special_min">
              <div class="spec_title">Specials</div>
              <div class="specl_box">
                <div class="spec_img"><img src="images/bestseller1.jpg" alt="Special img" width="80" /></div>
                <div class="spec_sub_title"><a href="#">Raspberry Orchid</a></div>
                <div class="spec_price">$100<span>$150</span></div>
                <div class="clr"></div>
              </div>
              <div class="specl_box">
                <div class="spec_img"><img src="images/bestseller1.jpg" alt="Special img" width="80" /></div>
                <div class="spec_sub_title"><a href="#">Raspberry Orchid</a></div>
                <div class="spec_price">$100<span>$150</span></div>
                <div class="clr"></div>
              </div>
              <div class="specl_box">
                <div class="spec_img"><img src="images/bestseller1.jpg" alt="Special img" width="80" /></div>
                <div class="spec_sub_title"><a href="#">Raspberry Orchid</a></div>
                <div class="spec_price">$100<span>$150</span></div>
                <div class="clr"></div>
              </div>
            </div>
            <div class="special_min">
              <div class="spec_title">Bestsellers</div>
              <div class="raspberry_orchid_bx"> <img src="images/raspberry_orchid.jpg" alt="raspberry orchid" />
                <div class="raspberry_titl"><a href="#">Raspberry Orchid</a></div>
                <div class="raspberry_price">34.99 AED</div>
              </div>
            </div>
          </div>
          
          <div class="span9">
           
            <div class="list_area">
             <div class="filtering_area">
               <div class="additional_txt">Additional Filterng : </div>
               <div class="additional_frm">
                 
                <div class="drop_bx">
                 <select class="select" title="Select one">
                  <option>Default</option>
                  <option>Name (A to Z)</option>
                  <option selected="selected">Name (Z to A)</option>                
                </select>
              </div>
              
            </div>
          </div>
          
          <div class="show_count">
           <div class="additional_txt">Show :</div>
           <div class="additional_frm">
             <div class="drop_bx"><select class="select" title="Select one">
               <option>12</option>
               <option>25</option>
               <option selected="selected">50</option>
               <option>100</option>
               <option>150</option>
               <option>200</option>
             </select></div>
           </div>
         </div>
         <div class="cat_view">
           <div class="additional_txt">Display :</div>
           <div class="list_view"><a href="#"><i class="fa fa-list"></i></a></div>
           <div class="list_view"><a href="#"><i class="fa fa-th-large"></i></a></div>
         </div>                    
       </div>
       
       <div class="row">
        <?php 
        $sql = "SELECT * FROM `tbl_product` WHERE `sub_category_id` = ".base64_decode($_GET['id'])."";
        $res = mysqli_query($conn,$sql);

        while($row = mysqli_fetch_array($res))
        {
          ?>
          <div class="span3">
            <div class="raspberry_orchid_bx"> 
              <center>
                <img src="<?php echo BASE_ADMIN_URL; ?>upload/product_img/<?php echo $row["image"];?>" style="height:250px;" alt="<?php echo $row["product_name"]; ?> "  />
              </center>
              <div class="raspberry_titl"><?php echo $row["product_name"]; ?></div>
              <div class="raspberry_price"><?php echo $row["price"]; ?></div>
              
              <div class="collection_star">
               <div class="collection_pic"><img src="images/stars.png" alt="stars"></div>
               <div class="collection_txt">Basic Collection</div>
               <div class="clr"></div>
             </div>
             
             <div class="rasberry_bt_area">
               <div class="cart_icon"><a href="#" class="add_to_cart" product_id="<?php echo base64_encode($row["id"]);?>"><img src="images/cart.png"  alt="cart"  ></a></div>
               <div class="cart_icon"><a href="#"><img src="images/fevorite.png" alt="fevorite" /></a></div>
               <div class="cart_icon"><a href="#"><img src="images/add-wish.png" alt="add-wish" /></a></div>
             </div>
             
           </div>
         </div>
       <?php } ?>
     </div>
     
     <div style="height:30px;"></div>
     
     <!--paging-start-here-->
     <div class="paging_btm">
       <ul>
         <li><a href="#"><span><i class="fa fa-angle-double-left"></i></span> Previous</a></li>
         <li><a href="#" class="act">1</a></li>
         <li><a href="#">2</a></li>
         <li><a href="#">3</a></li>
         <li><a href="#">4</a></li>                    
         <li><a href="#">Next <span><i class="fa fa-angle-double-right"></i></span></a></li>
         
       </ul>
     </div>
     
   </div>
 </div>
</div>
</div>
</div>
</div>
<!-- content end--> 

<?php include BASE_PATH."include/footer.php" ?>

<script type="text/javascript" src="js/jquery-1.8.2.js"></script>
<script>
  $(document).ready(function(){
    
    $('.add_to_cart').click(function(){
     var product_id = $(this).attr("product_id");
     var site_url = '<?php echo BASE_URL; ?>';
     $.ajax({
      type:"post",
      async:false,
      url:site_url+'ajax.php',
      data:{ ajaxcall1:1, 
       pro_id:product_id
     },
     success:function(result){
       $('#Cart_Value').html(result);
     }
   });
   });

    $('.add_to_cart').click(function(){
     var product_id = $(this).attr("product_id");
     var site_url = '<?php echo BASE_URL; ?>';
     $.ajax({
      type:"post",
      async:false,
      url:site_url+'ajax.php',
      data:{ ajaxcall2:2, 
       pro_id:product_id
     },
     success:function(result){                           
      $('#Cart_Box').html(result);
    }
  });
   });

  });
</script>

</body>
</html>

