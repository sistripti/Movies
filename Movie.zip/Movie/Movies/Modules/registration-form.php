
<?php
session_start(); 
?>
<!DOCTYPE html>
<html>
<head>
    <title>Registration form</title>
    <style type="text/css">
      .error{ color: red;  }
    </style>
</head>
<body>
<div>
    <?php if(isset($_SESSION['success'])) { ?>
    
           <span style="color:green;"><?php echo $_SESSION['success']; ?></span>
    
    <?php unset($_SESSION['success']); } else if(isset($_SESSION['error'])){ ?>
    
           <span style="color:red;"><?php echo $_SESSION['error']; ?></span>
    
    <?php unset($_SESSION['error']); } ?>  


    <form id="loginForm" name="loginForm" method="post" action="registration-store.php">
       	<span>First Name <span class="error">*</span> :</span>
        <input type="text" name="first_name" id="first_name" value="" placeholder="First Name">
        <span class="error" id="err_first_name"></span>
        <br>
        <hr>
        <span>Last Name :</span>
        <input type="text" name="last_name"  id="last_name" value="" placeholder="Last Name" >
        <span class="error" id="err_last_name"></span>
        <br>
        <hr>
        <span>Email:</span>
        <input type="email" name="Email" id="Email" value="" placeholder="Email" > 
        <span class="error" id="err_Email"></span>
        <br>
        <hr>
        <span>Gender: <br></span>
         <input type="radio"  name="Gender"  value="female"> Female
         <input type="radio"  name="Gender"  value="male"> Male
         <input type="radio"  name="Gender"  value="other"> Others
         <span class="error" id="err_Gender"></span>
        <br>
        <hr>
        <span> Hobbies <br></span>

        <input type="checkbox" name="Hobbies[]" value="Sports">Sports <br>
        <input type="checkbox" name="Hobbies[]" value="Dramatics">Dramatics<br>
        <input type="checkbox" name="Hobbies[]" value="Literary">Literary <br>
        <input type="checkbox" name="Hobbies[]" value="Music">Music <br>
        <input type="checkbox" name="Hobbies[]" value="Others">Others <br>
        <span class="error" id="err_Hobbies"></span>
        <br>
        <hr>
        <span>Password:</span>
        <input type="password" name="Password" id="Password" value="" placeholder="Password" > 
        <span class="error" id="err_Password"></span>
        <br>
        <hr>
        <span>Confirm Password:</span>
        <input type="password" name="Confirm_Password" id="Confirm_Password" value="" placeholder="Confirm_Password"  > 
        <span class="error" id="err_Confirm_Password"></span>
        <br>
        <hr>
        <span>&nbsp;</span>
        <input type="submit" name="submit"  id="submit" value="Submit">
    </form>
    <br>
    <span>OR</span>
    <br>
    <a href="login-form.php">Login</a>
</div>
</body>
<script type="text/javascript" src="js/jquery-1.11.3.min.js"></script>
<script>
    $(document).ready(function(){
      $('#submit').click(function(){
          var first_name = $('#first_name').val();
          var last_name = $('#last_name').val();
          var email = $('#Email').val();
          var gender = $('#Gender').val();
          var password = $('#Password').val();
          var confirmPassword = $('#Confirm_Password').val();
          var hobbies=$('input[name="Hobbies[]"]:checked').length;
          var flag = 0;

          $("#err_first_name").html('');
          $("#err_last_name").html('');
          $("#err_Email").html('');
          $("#err_Gender").html('');
          $("#err_Hobbies").html('');
          $("#err_Password").html('');
          $("#err_Confirm_Password").html('');
          
          if(first_name == '')
          {
            $("#err_first_name").html('Please enter first name.');
            /*$("#err_first_name").css('color','red');*/
            flag = 1;            
          }
          if(last_name == '')
          {
            $("#err_last_name").html('Please enter last name.');
            flag = 1;            
          }
          if(email == '')
          {
            $("#err_Email").html('Please enter email id.');
            flag = 1;            
          }


          if($('input[name=Gender]:checked').length<=0)
          { 


            $("#err_Gender").html('Select Gender');
            flag = 1;   
          
          }

        
          if(hobbies<=0)
          {

           $("#err_Hobbies").html('Please select atleast one..');
            flag = 1;  

          }

          if(password == '')
          {
            $("#err_Password").html('Please enter password.');
            flag = 1;            
          }
          if(confirmPassword == '')
          {
            $("#err_Confirm_Password").html('Please enter confirm password.');
            flag = 1;            
          }
          else if(confirmPassword!=password)
          {
            $("#err_Confirm_Password").html("Incorect password");
            flag = 1;              
          }
          /*else if (confirmpassword != password)
          {
            alert("HERE");
            $("#err_Confirm_Password").html("Incorect password");
            flag = 1;              
            
          }*/

          if(flag == 1)
          {
            return false;
          }
          else
          {
            //$("#loginForm").submit();
            return true;
          }

          /*if(first_name == ""){
             alert('Please enter first name'); 
          }*/
      });
    });
</script>
</html>