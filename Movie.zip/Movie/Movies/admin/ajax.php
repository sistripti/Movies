<?php
include "/opt/lampp/htdocs/Tripti/Movies/Moviesdata/admin/include/connect.php";
$outputdata = "";


if(isset($_POST['ajaxcall1'])){
   $sql = "SELECT 
                tbl_sub_category.id, 
                tbl_sub_category.sub_category_name,
                tbl_sub_category.category_id,
                tbl_category.category_name
           FROM tbl_sub_category
           INNER JOIN tbl_category 
                ON tbl_category.id=tbl_sub_category.category_id 
           WHERE tbl_sub_category.category_id = ".$_POST['cat_id']."
          "; 
   $res = mysqli_query($conn,$sql);
   $outputdata .= "<option value=''>--Select--</option>";
   while ($row = mysqli_fetch_array($res)) {
     $outputdata .= "<option value='".$row['id']."'>".$row['sub_category_name']."</option>";
   }
}


echo $outputdata;
?>