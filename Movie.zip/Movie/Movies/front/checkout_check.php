<?php 
include "/opt/lampp/htdocs/Soham/SarikaHomeAppliances/anthiaflower/front/include/connect.php";
session_start();

if(isset($_POST['Checkout']))
{
   if(isset($_SESSION['email_id']) && isset($_SESSION['first_name'])  && isset($_SESSION['last_name']))
   {
   		$sql = "SELECT `id`, `first_name`, `last_name`, `email_id`
           		FROM `tbl_user_registration` 
           		WHERE `email_id` = '".$_SESSION["email_id"]."' AND `password` = '".$_SESSION["password"]."'";

         $res  = mysqli_query($conn,$sql);
   		 $rows = mysqli_fetch_array($res);
		 
		 $sql_update ="UPDATE `tbl_cart` SET `user_id` = '".$rows["id"]."', `checkout` = '"."YES"."' WHERE `user_id` = '".$_SESSION["user_id"]."'";
		 $res_update = mysqli_query($conn,$sql_update);
		 
		   $_SESSION["user_id"] = $rows["id"];
    	 $_SESSION['first_name']  = $rows['first_name'];
    	 $_SESSION['last_name']   = $rows['last_name'];
    	 $_SESSION['email_id']    = $rows['email_id'];
    	 
    	 $_SESSION['success']     = "Login successfully";
    	 header('Refresh: 0; url=checkout.php');
   }
   else
   {
   		if(!isset($_SESSION['email_id']) && !isset($_SESSION['first_name'])  && !isset($_SESSION['last_name']))
   {
		 $_SESSION['error'] = "You need to login before checkout.";
		 header('Refresh: 0; url=user_login.php');
   }
}

}
   
?>