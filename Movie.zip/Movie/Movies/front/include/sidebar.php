<div class="span3">
            <div class="side-menu">
              <div class="side-menu-title">
                <h3>Product Categories
                  <div class="side-menu-spach"></div>
                </h3>
              </div>
              <div id="menusidebar">
                <ul>
                  <li><a href="#">Shop By Type</a></li>
                  <li><a href="#">Price</a></li>
                  <li><a href="#">Gifts Collection</a></li>
                  <li><a href="#">Birthdays</a></li>
                  <li><a href="#">Specialities</a></li>
                </ul>
              </div>
              <div class="clr"></div>
            </div>
            <div class="special_min">
              <div class="spec_title">Specials</div>
              <div class="specl_box">
                <div class="spec_img"><img src="images/bestseller1.jpg" alt="Special img" width="80" /></div>
                <div class="spec_sub_title"><a href="#">Raspberry Orchid</a></div>
                <div class="spec_price">$100<span>$150</span></div>
                <div class="clr"></div>
              </div>
              <div class="specl_box">
                <div class="spec_img"><img src="images/bestseller1.jpg" alt="Special img" width="80" /></div>
                <div class="spec_sub_title"><a href="#">Raspberry Orchid</a></div>
                <div class="spec_price">$100<span>$150</span></div>
                <div class="clr"></div>
              </div>
              <div class="specl_box">
                <div class="spec_img"><img src="images/bestseller1.jpg" alt="Special img" width="80" /></div>
                <div class="spec_sub_title"><a href="#">Raspberry Orchid</a></div>
                <div class="spec_price">$100<span>$150</span></div>
                <div class="clr"></div>
              </div>
            </div>
            <div class="special_min">
              <div class="spec_title">Bestsellers</div>
              <div class="raspberry_orchid_bx"> <img src="images/raspberry_orchid.jpg" alt="raspberry orchid" />
                <div class="raspberry_titl"><a href="#">Raspberry Orchid</a></div>
                <div class="raspberry_price">34.99 AED</div>
              </div>
            </div>
          </div>