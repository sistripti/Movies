<?php
include "/opt/lampp/htdocs/Tripti/Movies/Moviesdata/admin/include/connect.php";
session_start();
if(isset($_POST['Edit']))
{
	if(isset($_POST['Category_Name_Select'])){ $Category_Name_Select = $_POST['Category_Name_Select']; } else { $Category_Name_Select = ""; }

	if(isset($_POST['Sub_Category_Id'])){ $Sub_Category_Id = $_POST['Sub_Category_Id']; } else { $Sub_Category_Id = ""; }
  
	$sql ="UPDATE `tbl_category` SET `category_name` = '".$Category_Name_Select."' WHERE `id` = ".base64_decode($Sub_Category_Id)."";

	$result = mysqli_query($conn,$sql) or die('Error querying database.');

	mysqli_close($conn);

	$_SESSION['success'] = "Product updated successfully";

    header('Refresh: 0; url=manage.php');
	
};
?>
