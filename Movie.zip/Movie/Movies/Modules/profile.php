
<?php
session_start(); 
?>
<!DOCTYPE html>
<html>
<head>
    <title>Profile page</title>
</head>
<body>
  <div>
      <?php if(isset($_SESSION['success'])) { ?>
      
             <span style="color:green;"><?php echo $_SESSION['success']; ?></span>
      
      <?php unset($_SESSION['success']); } else if(isset($_SESSION['error'])){ ?>
      
             <span style="color:red;"><?php echo $_SESSION['error']; ?></span>
      
      <?php unset($_SESSION['error']); } ?>  

      <table border="1">
        <tr>
          <th>First Name </th> <td><?php if(!empty($_SESSION['first_name'])){ echo $_SESSION['first_name'];  } ?></td>
        </tr>
        <tr>
          <th>Last Name </th> <td><?php if(!empty($_SESSION['last_name'])){ echo $_SESSION['last_name'];  } ?></td>
        </tr>
        <tr>
          <th>Email </th> <td><?php if(!empty($_SESSION['email'])){ echo $_SESSION['email'];  } ?></td>
        </tr>
        <tr>
          <th>Gender </th> <td><?php if(!empty($_SESSION['gender'])){ echo $_SESSION['gender'];  } ?></td>
        </tr>
      </table>
  <a href="all-users.php">All users</a> |
  <a href="category.php">Category</a> |
  <a href="subCategory.php">Sub-Category</a> |
  <a href="logout.php">logout</a>
  </div>
</body>
</html>