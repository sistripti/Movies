
<?php
session_start(); 
?>
<!DOCTYPE html>
<html>
<head>
    <title>Login form</title>
</head>
<body>
<div>
    <?php if(isset($_SESSION['success'])) { ?>
    
           <span style="color:green;"><?php echo $_SESSION['success']; ?></span>
    
    <?php unset($_SESSION['success']); } else if(isset($_SESSION['error'])){ ?>
    
           <span style="color:red;"><?php echo $_SESSION['error']; ?></span>
    
    <?php unset($_SESSION['error']); } ?>  


    <form id="loginForm" name="loginForm" method="post" action="login.php">
       	<span>Email :</span>
        <input type="text" name="email" id="email" value="<?php if(!empty($_SESSION['email'])){ echo $_SESSION['email']; unset($_SESSION['email']); } ?>" placeholder="Email Id">
        <br>
        <hr>
        <span>Password :</span>
        <input type="password" name="password"  id="password" value="<?php if(!empty($_SESSION['password'])){ echo $_SESSION['password']; unset($_SESSION['password']); } ?>" placeholder="Password">
        <br>
        <hr>
        <span>&nbsp;</span>
        <input type="submit" name="submit"  id="submit" value="Submit">
    </form>
    <br>
    <span>OR</span>
    <br>
    <a href="registration-form.php">Registration</a>
</div>
</body>
<script type="text/javascript" src="js/jquery-1.11.3.min.js"></script>
<script>
    $(document).ready(function(){
      $('#submit').click(function(){
          var first_name = $('#first_name').val();
          if(first_name == ""){
             alert('Please enter first name'); 
          }
      });
    });
</script>
</html>