<!--footer start-->
<div class="footer_links">
  <div class="container">
      <div class="row">
          <div class="span12">
              <div class="row">
                  <div class="span3">
                      <div class="footer_heading">About US</div>
                        <div class="heading_bor"></div>
                        <div class="menu_name">
                          <ul>
                              <li><a href="#"><i class="fa fa-caret-right"></i>About Us</a></li>
                                <li><a href="#"><i class="fa fa-caret-right"></i>Antheia Flowers Stories</a></li>
                                <li><a href="#"><i class="fa fa-caret-right"></i>Our Press</a></li>
                                <li><a href="#"><i class="fa fa-caret-right"></i>Terms &amp; Conditions</a></li>
                                <li><a href="#"><i class="fa fa-caret-right"></i>Privacy Policy</a></li>
                                <li><a href="#"><i class="fa fa-caret-right"></i>Sitemap</a></li>
                            </ul>
                        </div>
                    </div>
                    
                    <div class="span3">
                      <div class="footer_heading">Customer Service</div>
                        <div class="heading_bor"></div>
                        <div class="menu_name">
                          <ul>
                              <li><a href="#"><i class="fa fa-caret-right"></i>Contact Us</a></li>
                                <li><a href="#"><i class="fa fa-caret-right"></i>Customer service</a></li>
                                <li><a href="#"><i class="fa fa-caret-right"></i>Privacy policy</a></li>
                                <li><a href="#"><i class="fa fa-caret-right"></i>FAQ's</a></li>
                                <li><a href="#"><i class="fa fa-caret-right"></i>My Account (Log In)</a></li>
                            </ul>
                        </div>
                    </div>
                    
                    <div class="span3">
                      <div class="footer_heading">Our Products</div>
                        <div class="heading_bor"></div>
                        <div class="menu_name">
                          <ul>
                              <li><a href="#"><i class="fa fa-caret-right"></i>How to apply &amp; Tips</a></li>
                                <li><a href="#"><i class="fa fa-caret-right"></i>Sample Request</a></li>
                                <li><a href="#"><i class="fa fa-caret-right"></i>Product Features</a></li>
                                <li><a href="#"><i class="fa fa-caret-right"></i>Customer Stories</a></li>
                            </ul>
                        </div>
                    </div>
                    
                    <div class="span3">
                      <div class="footer_heading">Newsletter Sing Up</div>
                        <div class="heading_bor"></div>
                        <div class="menu_name">
                          <input name="" type="text" class="frm_newsletter" placeholder="Enter your E-mail address " />
                            <div class="bt_newsletter"><input name="" type="button" value="Subscribe" class="btn_news" /></div>
                            <div class="footer_social">
                            <ul>
                            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                            <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                            </ul>
                            </div>
                        </div>
                    </div>
                    
                    
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Footer end--> 

<div class="footer_copyright">
  <div class="container">
      <div class="row">
          <div class="span12">
            <div class="footer_copy_main">
              <div class="copyright_l">&copy; 2015 Antheia Flowers Ltd. All Rights Reserved.</div>
                <div class="copyright_r">
                  <ul>
                      <li>We Accept These Cards :</li>
                      <li><a href="#"><img src="<?php echo BASE_URL; ?>images/payment_1.jpg" alt="payment_1" /></a></li>
                        <li><a href="#"><img src="<?php echo BASE_URL; ?>images/payment_2.jpg" alt="payment_2" /></a></li>
                        <li><a href="#"><img src="<?php echo BASE_URL; ?>images/payment_3.jpg" alt="payment_3" /></a></li>
                        <li><a href="#"><img src="<?php echo BASE_URL; ?>images/payment_4.jpg" alt="payment_4" /></a></li>
                        <li><a href="#"><img src="<?php echo BASE_URL; ?>images/payment_5.jpg" alt="payment_5" /></a></li>
                    </ul>
        </div>
          </div>
                <div class="clr"></div>
            </div>
        </div>
    </div>
</div>




<!-- Bootstrap responsive --> 
<script type="text/javascript" language="javascript" src="<?php echo BASE_URL; ?>js/bootstrap.min.js"></script> 
<!-- Bootstrap responsive -->