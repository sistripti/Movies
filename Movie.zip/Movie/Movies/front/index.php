<?php include '/opt/lampp/htdocs/Soham/SarikaHomeAppliances/anthiaflower/front/include/header.php';  ?>

<!--Header start--> 
<div class="header"><img src="<?php echo BASE_URL; ?>images/header.jpg" alt="header" /></div>
<!--Header end--> 

<!--top three colums start--> 
<div class="thre_tab_head">
<div class="container">
<div class="row">
<div class="span12">
<div class="row">
<div class="span4"><div class="couter_collec_bx">
<div class="couter_collec_titl">THE COUTURE COLLECTION</div>
<div class="couter_collec_bt"><a href="#">explore</a></div>
</div></div>
<div class="span4"><div class="couter_collec_bx">
<div class="couter_collec_titl">MOTHER'S DAY FLOWERS</div>
<div class="couter_collec_bt"><a href="#">explore</a></div>
</div></div>
<div class="span4"><div class="couter_collec_bx">
<div class="couter_collec_titl">OCCASIONS COLLECTION</div>
<div class="couter_collec_bt"><a href="#">explore</a></div>
</div></div>
</div>
</div>
</div>
</div>
</div>
<!-- top three colums end--> 

<!--content start-->
<div class="container">

<div class="row">
<div class="span12">

<div class="row">

<div class="span6">
<div class="birthday_flowers_bx">
<img src="images/birthday_flowers.jpg" alt="birthday flowers" />
<div class="birthday_flowers_titl">Birthday Flowers</div>
<div class="couter_collec_bt"><a href="#">explore</a></div>
</div>
</div>

<div class="span6">
<div class="new_baby_gift_bx">
<img src="images/new_baby_gifts.jpg" alt="new baby gifts" />
<div class="birthday_flowers_titl">New Baby Gifts</div>
<div class="couter_collec_bt"><a href="#">explore</a></div>
</div>
</div>
<div class="clr"></div>

<div class="span12">
<div class="blogger_main_bx">
<div class="row">
<div class="span5"><div class="blogger_titl"><img src="images/bloggerss_picks.png" alt="bloggerss picks" /></div></div>
<div class="span7"><div class="blogger_cont">Which bouquets have your favorite blogger picked</div></div>
</div>
</div>
</div>

<div class="span4"><div class="raspberry_orchid_bx">
<img src="images/raspberry_orchid.jpg" alt="raspberry orchid" />
<div class="raspberry_titl">Raspberry Orchid</div>
<div class="raspberry_cont">Raspberry Orchids &amp; Sweet Avalanche Roses </div>
<div class="raspberry_price">34.99 AED</div>
<div class="raspberry_view_bt"><a href="#">View</a></div>
</div></div>
<div class="span4"><div class="raspberry_orchid_bx">
<img src="images/wishes.jpg" alt="wishes" />
<div class="raspberry_titl">Wishes</div>
<div class="raspberry_cont">Make A Wish With This Mix Of Flora </div>
<div class="raspberry_price">39.99 AED</div>
<div class="raspberry_view_bt"><a href="#">View</a></div>
</div></div>
<div class="span4"><div class="raspberry_orchid_bx">
<img src="images/coral.jpg" alt="coral" />
<div class="raspberry_titl">Coral</div>
<div class="raspberry_cont">Roses, Hypericum Berries &amp; Eustoma</div>
<div class="raspberry_price">75.00 AED</div>
<div class="raspberry_view_bt"><a href="#">View</a></div>
</div></div>

</div>

</div>
</div>
</div>
<!-- content end--> 

<?php include BASE_PATH.'include/footer.php'; ?>



</body>
</html>
