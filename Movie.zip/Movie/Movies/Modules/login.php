<?php 
include "connect.php";
session_start();
if(isset($_POST['submit']))
{
   $_SESSION['email'] = $_POST['email'];
   $_SESSION['password'] = $_POST['password'];

   if(isset($_POST['email']) && $_POST['email'] =="")
   { 
      $_SESSION['error'] = "Please enter email";
      header('Refresh: 0; url=login-form.php'); 
   } 
   else if(isset($_POST['password']) && $_POST['password'] =="") 
   { 
      $_SESSION['error'] = "Please enter password";
      header('Refresh: 0; url=login-form.php'); 
   } 
   $email    = $_POST['email'];
   $password = $_POST['password']; 

   /* sql query */
   $sql = "SELECT `id`, `first_name`, `last_name`, `email`, `gender`, `Hobbies` 
           FROM `registration_table` 
           WHERE `email` = '".$email."' AND `password` = '".$password."'";
   
   $res  = mysqli_query($conn,$sql);
   $rows = mysqli_fetch_array($res);

   if(count($rows) > 0){
    $_SESSION['id']          = $rows['id'];
    $_SESSION['first_name']  = $rows['first_name'];
    $_SESSION['last_name']   = $rows['last_name'];
    $_SESSION['email']       = $rows['email'];
    $_SESSION['gender']      = $rows['gender'];
    $_SESSION['success']     = "Login successfully";
    header('Refresh: 0; url=profile.php');  
   }
   else{
   
     $_SESSION['error'] = "Please enter valid credentials";
     header('Refresh: 0; url=login-form.php'); 
   
   }
}   
?>