<?php
include "/opt/lampp/htdocs/Tripti/Movies/Moviesdata/admin/include/connect.php";
session_start();

if(isset($_POST['Edit']))
{
	if(isset($_POST['Product_Name'])){ $Product_Name = $_POST['Product_Name']; } else { $Product_Name = ""; }
	if(isset($_POST['Sub_Category_Name_Select'])){ $Sub_Category_Name_Select = $_POST['Sub_Category_Name_Select']; } else { $Sub_Category_Name_Select = ""; }
	if(isset($_POST['Category_Name_Select'])){ $Category_Name_Select = $_POST['Category_Name_Select']; } else { $Category_Name_Select = ""; }
	if(isset($_POST['Product_Name_Id'])){ $Product_Name_Id = $_POST['Product_Name_Id']; } else { $Product_Name_Id = ""; }
	if (isset($_POST["Price"])){ $Price = $_POST["Price"];}else{ $Price = "";}

  	if(isset($_FILES["Upload_Image"]["name"])){

  		$Image=$_FILES["Upload_Image"]["name"];
 		
 		$uploaddir= "/opt/lampp/htdocs/Tripti/Movies/Moviesdata/admin/upload/product_img";
		$uploadfile=$uploaddir.'/'.basename($_FILES["Upload_Image"]["name"]);
		
		if(move_uploaded_file($_FILES["Upload_Image"]["tmp_name"],$uploadfile )){

			$sql = "UPDATE `tbl_product` SET `category_id`='".$Category_Name_Select."',`sub_category_id`= '".$Sub_Category_Name_Select."',`product_name` = '".$Product_Name."',`price` = '".$Price."',`image`='".$Image."' WHERE `id` = '".base64_decode($Product_Name_Id)."'";

			$result = mysqli_query($conn, $sql) or die('Error querying database.');
						
			$_SESSION['success'] = "Category updated successfully";
    		
    		header('Refresh: 0; url=manage.php');

    		exit;		
  		
  		}
	}
  
	$sql = "UPDATE `tbl_product` SET `category_id`='".$Category_Name_Select."',`sub_category_id`= '".$Sub_Category_Name_Select."',`product_name` = '".$Product_Name."',`price` = '".$Price."' WHERE `id` = '".base64_decode($Product_Name_Id)."'";
	
		$result = mysqli_query($conn, $sql) or die('Error querying database.');
		
		$_SESSION['success'] = "Category updated successfully";
    
    	header('Refresh: 0; url=manage.php');
	
}
?>
