<?php 
include "/opt/lampp/htdocs/Tripti/Movies/Moviesdata/admin/include/connect.php";
session_start();

if(isset($_POST["Save"]))
{
	if(isset($_POST["Category_Name"]))
	{
		$Category_Name=$_POST["Category_Name"];
	}
	else
	{
		$Category_Name = "";
	}
}

$sql = "SELECT `id`, `category_name` 
        FROM `tbl_category` 
        WHERE `category_name` = '".$Category_Name."'";
   
   $res  = mysqli_query($conn,$sql);
   $rows = mysqli_num_rows($res);


   if($rows > 0){
      $_SESSION['error'] = "The category name already exists.";
      header('Refresh: 0; url=add.php');    
   }
   else{

$sql = "INSERT INTO `tbl_category`(`category_name`)
        VALUES ('".$Category_Name."')";
   $res = mysqli_query($conn,$sql);
   if($res){
      $_SESSION['success'] = "Data has been store successfully";
      header('Refresh: 0; url=add.php');
   }
   else{
      $_SESSION['error'] = "Something went wrong";
      header('Refresh: 0; url=add.php');
   }
}

 ?>