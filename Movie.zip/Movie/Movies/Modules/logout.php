<?php
session_start(); 
session_destroy();
session_start();
$_SESSION['success'] = "Logout successfully";
header('Refresh: 0; url=login-form.php'); 
?>
