<footer>
<p>2015 © FLATY Admin Template.</p>
</footer>


<!--basic scripts-->
<script src="//ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
<script>window.jQuery || document.write('<script src="<?php echo BASE_URL; ?>assets/jquery/jquery-2.1.4.min.js"><\/script>')</script>
<script src="<?php echo BASE_URL; ?>assets/bootstrap/js/bootstrap.min.js"></script>
<script src="<?php echo BASE_URL; ?>assets/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<script src="<?php echo BASE_URL; ?>assets/jquery-cookie/jquery.cookie.js"></script>

<!--page specific plugin scripts-->
<script src="<?php echo BASE_URL; ?>assets/flot/jquery.flot.js"></script>
<script src="<?php echo BASE_URL; ?>assets/flot/jquery.flot.resize.js"></script>
<script src="<?php echo BASE_URL; ?>assets/flot/jquery.flot.pie.js"></script>
<script src="<?php echo BASE_URL; ?>assets/flot/jquery.flot.stack.js"></script>
<script src="<?php echo BASE_URL; ?>assets/flot/jquery.flot.crosshair.js"></script>
<script src="<?php echo BASE_URL; ?>assets/flot/jquery.flot.tooltip.min.js"></script>
<script src="<?php echo BASE_URL; ?>assets/sparkline/jquery.sparkline.min.js"></script>

<!--flaty scripts-->
<script src="<?php echo BASE_URL; ?>js/flaty.js"></script>
<script src="<?php echo BASE_URL; ?>js/flaty-demo-codes.js"></script>

    