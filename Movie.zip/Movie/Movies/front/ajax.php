<?php
include "/opt/lampp/htdocs/Soham/SarikaHomeAppliances/anthiaflower/admin/include/connect.php";
        define('BASE_ADMIN_URL', 'http://localhost/Soham/SarikaHomeAppliances/anthiaflower/admin/');

$outputdata = "";
session_start();

if(isset($_POST['ajaxcall1'])){

  $outputdata = 0;

  if (isset($_POST["pro_id"])) {

    if (isset($_SESSION["user_id"])) 
    {
      $sql_quant_show = "SELECT * FROM `tbl_cart` WHERE `user_id` = '".$_SESSION["user_id"]."'";
      $res_quant_show = mysqli_query($conn,$sql_quant_show);
      while ($rows_quant_show = mysqli_fetch_array($res_quant_show)) {
              $outputdata += $rows_quant_show["quantity"];
      }



      $sql = "SELECT * FROM `tbl_cart` WHERE `product_id` = '".base64_decode($_POST["pro_id"])."' AND `user_id` = '".$_SESSION["user_id"]."'";
      $res = mysqli_query($conn,$sql);
      $row = mysqli_fetch_array($res);

      if (mysqli_num_rows($res) > 0) 
      {
        $add_qty = ($row["quantity"] + 1) ;
        $sql2 = "UPDATE `tbl_cart` SET `quantity` = '".$add_qty."' WHERE `product_id` = '".base64_decode($_POST["pro_id"])."' AND `user_id` = '".$_SESSION["user_id"]."'";

        if(mysqli_query($conn,$sql2))
        {
          $outputdata += 1;
        }
      }

      else 
      {
        $sql2 = "INSERT INTO `tbl_cart`(`user_id`,
        `product_id`, 
        `quantity`) 
        VALUES ('".$_SESSION["user_id"]."',
        '".base64_decode($_POST["pro_id"])."',
        ".'1'.")";
        if(mysqli_query($conn,$sql2))
        {
          $outputdata += 1;
        }
      }
    }  

    else
    {
      $_SESSION["user_id"] = rand();
      $sql2 = "INSERT INTO `tbl_cart`(`user_id`,
      `product_id`, 
      `quantity`) 
      VALUES ('".$_SESSION["user_id"]."',
      '".base64_decode($_POST["pro_id"])."',
      ".'1'.")";
      if(mysqli_query($conn,$sql2))
      {
        $outputdata += 1;
      }
    }
  }
}

if(isset($_POST['ajaxcall2'])){

  if (isset($_POST["pro_id"])) {

    $sql_cart="SELECT tbl_cart.id,
    tbl_cart.user_id,
    tbl_cart.product_id,
    tbl_cart.quantity,
    tbl_product.price,
    tbl_product.product_name,
    tbl_product.image
    FROM `tbl_cart`
    INNER JOIN `tbl_product`
    ON tbl_product.id = tbl_cart.product_id WHERE `user_id` = '".$_SESSION["user_id"]."'";

    $res_cart = mysqli_query($conn,$sql_cart);

    while($row_cart = mysqli_fetch_array($res_cart)) 
    { 
      $image        = $row_cart["image"];
      $product_name = $row_cart["product_name"];
      $quantity     = $row_cart["quantity"];
      $price        = $row_cart["price"]; 

      $outputdata .=     '<div class="item_box">
      <div class="item_img"><img src="'.BASE_ADMIN_URL.'upload/product_img/'.$image.'"alt="logo" width="50" /></div>
      <div class="item_text">'.$product_name.'</div>
      <div class="item_nub">'.$quantity.'</div>
      <div class="item_price">'.$price.'</div>
      <div class="item_close"><a href="#"><i class="fa fa-times"></i></a></div>
      <div class="clr"></div>
      </div>';
      }
                        }
                      }

                      echo $outputdata;


                      ?>