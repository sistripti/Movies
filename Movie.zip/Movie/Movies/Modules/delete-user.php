<?php
include "connect.php";
session_start();
if (isset($_GET['id']))
{

	$id = base64_decode($_GET['id']);
	$sql = "DELETE FROM `registration_table` WHERE `id` = ".$id;
	$res = mysqli_query($conn,$sql);
	if($res)
	{
		header("Location: all-users.php");
	}
	else
	{
		header("Location: all-users.php");	
	}
}

?>