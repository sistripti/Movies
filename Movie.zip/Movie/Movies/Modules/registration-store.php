<?php 
include "connect.php";
session_start();
if(isset($_POST['submit']))
{
   $Hobbies =""; 
   if(isset($_POST['first_name'])){ $first_name = $_POST['first_name']; } else { $first_name = ""; }
   if(isset($_POST['last_name'])) { $last_name = $_POST['last_name']; } else{ $last_name = ""; }
   if(isset($_POST['Email'])){ $Email= $_POST['Email']; } else { $Email=""; }
   if(isset($_POST['Gender'])) { $Gender= $_POST['Gender']; } else { $Gender=""; }
   if(isset($_POST["Hobbies"]))
   {
      foreach ($_POST["Hobbies"] as $key => $value) 
      {
        $Hobbies .= $value.",";
      }
   }
   else
   {
      $Hobbies="";
   }
   if(isset($_POST['Password'])) { $Password=$_POST['Password']; } else { $Password=""; }

    $result=mysqli_query($conn ,"SELECT count(*) as total from registration_table WHERE email='".$Email."'");
    $data=mysqli_fetch_assoc($result);
    if($data['total'] > 0)
    {
      $_SESSION['error'] = "Email already exist.";
      header('Refresh: 0; url=registration-form.php');
    }
    else
    {
      /* sql query */
     $sql = "INSERT INTO `registration_table`(`first_name`,
                                              `last_name`,
                                              `email`,
                                              `gender`,
                                              `Hobbies`,
                                              `password`)
                                      VALUES ('".$first_name."',
                                              '".$last_name."',
                                              '".$Email."',
                                              '".$Gender."',
                                              '".substr($Hobbies, 0, -1)."',
                                              '".$Password."')";
     $res = mysqli_query($conn,$sql);
     if($res){
        $_SESSION['success'] = "Data has been store successfully";
        header('Refresh: 0; url=registration-form.php');
     }
     else
     {
        $_SESSION['error'] = "Something went wrong";
        header('Refresh: 0; url=registration-form.php');
     }   
    }
}
?>