<?php 
include "/opt/lampp/htdocs/Tripti/Movies/Moviesdata/admin/include/connect.php";
session_start();

if(isset($_POST["Save"]))
{
	if(isset($_POST["Category_Name"]))
	{
		$Category_Name=$_POST["Category_Name"];
	}
	else
	{
		$Category_Name = "";
	}
  if (isset($_POST["Sub_Category_Name"])) {

    $Sub_Category_Name = $_POST["Sub_Category_Name"];

  }
  else
  {
       $Sub_Category_Name ="";
  }
}

$sql = "SELECT * 
        FROM `tbl_sub_category` 
        WHERE category_id = '$Category_Name' 
        AND  sub_category_name = '$Sub_Category_Name'";
   
   $res  = mysqli_query($conn,$sql);
   $rows = mysqli_num_rows($res);

   if($rows > 0){
      $_SESSION['error'] = "The sub category name already exists.";
      header('Refresh: 0; url=add.php');    
   }
   else{

$sql = "INSERT INTO `tbl_sub_category`(`category_id`,`sub_category_name`)
        VALUES ('".$Category_Name."','".$Sub_Category_Name."')";

   $res = mysqli_query($conn,$sql) or die('Error querying');
   mysqli_close($conn);

      $_SESSION['success'] = "sub category added successfully";
      header('Refresh: 0; url=add.php');
   }

 ?>