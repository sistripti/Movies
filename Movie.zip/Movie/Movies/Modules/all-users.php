<script type="text/javascript" src="js/jquery-1.11.3.min.js"></script>
<?php 
include "connect.php";
   /* sql query */
   $res = [];
   $sql = "SELECT * FROM `registration_table`";
   $res = mysqli_query($conn,$sql);
   
   echo '<table border="1">';
   echo '<tr><th>First Name</th><th>Last Name</th><th>Email</th><th>Action</th></tr>';
   while ($row = mysqli_fetch_array($res)) {
      echo '<tr><td>'.$row['first_name'].'</td><td>'.$row['last_name'].'</td><td>'.$row['email'].'</td>
      	<td><a href="javascript:void(0)" data-id="'.base64_encode($row['id']).'" class="delete" >Delete</a></td>
      </tr>';
   }
   echo "</table>";
?>
<a href="profile.php">Profile</a>
<a href="logout.php">logout</a>
<script type="text/javascript">
	$(document).on('click', '.delete', function(){
		var id = $(this).attr('data-id');
		var deleteURL = 'delete-user.php?id='+id;
		if(id!='')
		{
			if (confirm('Are you sure to delete this record')) {
			    window.location.href = deleteURL;
			} else {
			    return false;
			}
			
		}
	});
</script>