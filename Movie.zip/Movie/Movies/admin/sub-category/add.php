    <?php session_start();
include "/opt/lampp/htdocs/Tripti/Movies/Moviesdata/admin/include/connect.php";
          include BASE_PATH."include/connect.php"; ?>
        <!-- BEGIN Container -->
        <div class="container" id="main-container">
            <?php include BASE_PATH."include/sidebar.php"; ?>
            <!-- BEGIN Content -->
            <div id="main-content">
                <!-- BEGIN Page Title -->
                <div class="page-title">
                    <div>
                        <h1><i class="fa fa-file-o"></i> Sub-Category</h1>
                    </div>
                </div>
                <!-- END Page Title -->
                <!-- BEGIN Breadcrumb -->
                <div id="breadcrumbs">
                    <ul class="breadcrumb">
                        <li>
                            <i class="fa fa-home"></i>
                            <a href="<?php echo BASE_URL?>index.php">Home</a>
                            <span class="divider"><i class="fa fa-angle-right"></i></span>
                        </li>
                        <li class="active">Add Sub-Category</li>
                    </ul>
                </div>
                <!-- END Breadcrumb -->
                <!-- BEGIN Main Content -->
                <div class="row">
                    <div class="col-md-12">
                        <div class="box">
                            <div class="box-title">
                                <h3><i class="fa fa-bars"></i> Sub-Category</h3>
                                <div class="box-tool">
                                    <a data-action="collapse" href="#"><i class="fa fa-chevron-up"></i></a>
                                    <a data-action="close" href="#"><i class="fa fa-times"></i></a>
                                </div>
                            </div>
                            <div class="box-content">
                              <?php if(isset($_SESSION['success'])) { ?>
    
                                 <span style="color:green;"><?php echo $_SESSION['success']; ?></span>
    
                                 <?php unset($_SESSION['success']); } else if(isset($_SESSION['error'])){ ?>
    
                                 <span style="color:red;"><?php echo $_SESSION['error']; ?></span>
    
                                 <?php unset($_SESSION['error']); } ?>

                                 <form action="store.php" method="post" class="form-horizontal">
                                    <div class="form-group">
                                       <label class="col-sm-3 col-lg-2 control-label">Category</label>
                                       <div class="col-sm-9 col-lg-10 controls">
                                          <select class="form-control" name="Category_Name" id="Category_Name">
                                              <option value="">--Select--</option>
                                              
                                              <?php 

                                                  $sql= "SELECT * FROM `tbl_category`";
                                                  $res=mysqli_query($conn,$sql);
                                                  while ($row = mysqli_fetch_array($res)) { ?>
                                                  <option value="<?php echo $row['id']; ?>"><?php echo $row['category_name']; ?> </option>
                                                  <?php }?>  
                                          </select>
                                          <span class="help-inline" style="color:red;"></span>
                                       </div>
                                    </div>
                                    <div class="form-group">
                                       <label class="col-sm-3 col-lg-2 control-label">Sub-Category Name</label>
                                       <div class="col-sm-9 col-lg-10 controls">
                                          <input type="text" name="Sub_Category_Name" id="Sub_Category_Name" placeholder="small" class="form-control num_restrict input-sm" />
                                          <span class="help-inline error" style="color:red;"></span>
                                       </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2">
                                           <button type="submit" name="Save" id="Save" class="btn btn-primary"><i class="fa fa-check"></i> Save</button>
                                           <button type="button" name="Cancel" id="Cancel" class="btn">Cancel</button>
                                        </div>
                                    </div>
                                 </form>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- END Main Content -->
                <?php include BASE_PATH."include/footer.php"; ?>
                <a id="btn-scrollup" class="btn btn-circle btn-lg" href="#"><i class="fa fa-chevron-up"></i></a>
            </div>
            <!-- END Content -->
        </div>
        <!-- END Container -->
        <script type="text/javascript" src="/opt/lampp/htdocs/Soham/SarikaHomeAppliances/anthiaflower/admin/js/jquery-1.11.3.min.js"></script>
    <script>        
        $(document).ready(function(){
          
            $(".num_restrict").keypress(function(event){
                        var inputValue = event.which;
                        $(this).parent().find('.wrapDiv').html('');
                        if(!(inputValue >= 65 && inputValue <= 122) && (inputValue != 32 && inputValue!=8 && inputValue != 0 && inputValue!=46 && inputValue!=44 && inputValue!=13  && inputValue!=46)) 
                        { 
                            $(this).parent().find('.error,.err').html('only character allow');
                            event.preventDefault(); 
                        }
                        else
                        {
                            $(this).parent().find('.error,.err').html('');
                        }
                });

            $("#Save").click(function(){
                        var Category_Name = $("#Category_Name").val();
                        var Sub_Category_Name = $("#Sub_Category_Name").val();

                        if(Category_Name=="") 
                        { 
                            alert("category name cannot be blank");

                            return false;
                        }
                        else if (Sub_Category_Name=="") {

                            alert("sub category name cannot be blank"); 
                            return false;             
                        
                        }
                        else
                        {
                            return true;
                        }
                });

        });


    </script>

    </body>
</html>
