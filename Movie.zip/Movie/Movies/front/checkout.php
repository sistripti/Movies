<?php 
include "/opt/lampp/htdocs/Soham/SarikaHomeAppliances/anthiaflower/front/include/header.php"; 
include BASE_PATH.'include/connect.php'; 
?> 

<!--content start-->
<div class="container">
  <div class="row">
    <div class="span12">
      <div class="middle_content">
        <div class="row">
          <div class="span9">
            <div class="head_area">
              <div class="related_prod">Checkout  <div><?php if(isset($_SESSION['success'])) { ?>

             <span style="color:green;"><?php echo $_SESSION['success']; ?></span>

             <?php unset($_SESSION['success']); } else if(isset($_SESSION['error'])){ ?>

               <span style="color:red;"><?php echo $_SESSION['error']; ?></span>

               <?php unset($_SESSION['error']); } ?></div></div>
              <div class="prod_bor"></div>
            </div>
            <div id='cssmenu'>
              <ul>
                <li><a href='#'><span>Step 1 : Checkout Option</span></a></li>
                <li class='has-sub active'><a href='#'><span>Step 2 : Billing Details</span></a>
                  <ul>
                    <li>
                      <div class="radio_area">
                        <input type="radio" name="radiog_lite" id="radio1" class="css-checkbox" />
                        <label for="radio1" class="css-label radGroup1">I want to use an existing address</label>
                      </div>
                      <div class="radio_area">
                        <textarea name="" cols="" rows="4" style="resize:none;" class="input_email"></textarea>
                      </div>
                      <div class="radio_area">
                        <input type="radio" name="radiog_lite" id="radio2" class="css-checkbox" />
                        <label for="radio2" class="css-label radGroup1">I want to use a new address</label>
                      </div>
                      <div class="user_one">
                        <div class="row">
                          <div class="span2">
                            <div class="email_txt_check"><span>*</span> First Name :</div>
                          </div>
                          <div class="span4">
                            <div class="a">
                              <input name="" type="text" class="input_email" />
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="user_one">
                        <div class="row">
                          <div class="span2">
                            <div class="email_txt_check"><span>*</span> Last Name :</div>
                          </div>
                          <div class="span4">
                            <div class="a">
                              <input name="" type="text" class="input_email" />
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="user_one">
                        <div class="row">
                          <div class="span2">
                            <div class="email_txt_check"><span>*</span> Company :</div>
                          </div>
                          <div class="span4">
                            <div class="a">
                              <input name="" type="text" class="input_email" />
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="user_one">
                        <div class="row">
                          <div class="span2">
                            <div class="email_txt_check"><span>*</span> Address 1 :</div>
                          </div>
                          <div class="span4">
                            <div class="a">
                              <input name="" type="text" class="input_email" />
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="user_one">
                        <div class="row">
                          <div class="span2">
                            <div class="email_txt_check"><span>*</span> Address 2 :</div>
                          </div>
                          <div class="span4">
                            <div class="a">
                              <input name="" type="text" class="input_email" />
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="user_one">
                        <div class="row">
                          <div class="span2">
                            <div class="email_txt_check"><span>*</span> City :</div>
                          </div>
                          <div class="span4">
                            <div class="a">
                              <input name="" type="text" class="input_email" />
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="user_one">
                        <div class="row">
                          <div class="span2">
                            <div class="email_txt_check"><span>*</span> Post Code :</div>
                          </div>
                          <div class="span4">
                            <div class="a">
                              <input name="" type="text" class="input_email" />
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="user_one">
                        <div class="row">
                          <div class="span2">
                            <div class="email_txt_check"><span>*</span> Country :</div>
                          </div>
                          <div class="span4">
                            <div class="a">
                              <div class="drop_bx">
                                <select class="select" title="Select one">
                                  <option selected="selected">Select Country</option>
                                  <option>India</option>
                                  <option>Brazil</option>
                                  <option>Korea</option>
                                  <option>Russia</option>
                                  <option>America</option>
                                </select>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="user_one">
                        <div class="row">
                          <div class="span2">
                            <div class="email_txt_check"><span>*</span> * Region / State :</div>
                          </div>
                          <div class="span4">
                            <div class="a">
                              <div class="drop_bx">
                                <select class="select" title="Select one">
                                  <option selected="selected"> --- Please Select --- </option>
                                  <option>Funafuti</option>
                                </select>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="clr"></div>
                      <div class="cont_bt"><a href="#">Continue <i class="fa fa-caret-right"></i></a></div>
                    </li>
                  </ul>
                </li>
                <li class='has-sub'><a href='#'><span>Step 3 : Delivery Details</span></a>
                  <ul>
                    <li>
                      <div class="radio_area">
                        <input type="radio" name="radiog_lite" id="radio3" class="css-checkbox" />
                        <label for="radio3" class="css-label radGroup1">I want to use an existing address</label>
                      </div>
                      <div class="radio_area">
                        <textarea name="" cols="" rows="4" style="resize:none;" class="input_email"></textarea>
                      </div>
                      <div class="radio_area">
                        <input type="radio" name="radiog_lite" id="radio4" class="css-checkbox" />
                        <label for="radio4" class="css-label radGroup1">I want to use a new address</label>
                      </div>
                      <div class="user_one">
                        <div class="row">
                          <div class="span2">
                            <div class="email_txt_check"><span>*</span> First Name :</div>
                          </div>
                          <div class="span4">
                            <div class="a">
                              <input name="" type="text" class="input_email" />
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="user_one">
                        <div class="row">
                          <div class="span2">
                            <div class="email_txt_check"><span>*</span> Last Name :</div>
                          </div>
                          <div class="span4">
                            <div class="a">
                              <input name="" type="text" class="input_email" />
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="user_one">
                        <div class="row">
                          <div class="span2">
                            <div class="email_txt_check"><span>*</span> Company :</div>
                          </div>
                          <div class="span4">
                            <div class="a">
                              <input name="" type="text" class="input_email" />
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="user_one">
                        <div class="row">
                          <div class="span2">
                            <div class="email_txt_check"><span>*</span> Address 1 :</div>
                          </div>
                          <div class="span4">
                            <div class="a">
                              <input name="" type="text" class="input_email" />
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="user_one">
                        <div class="row">
                          <div class="span2">
                            <div class="email_txt_check"><span>*</span> Address 2 :</div>
                          </div>
                          <div class="span4">
                            <div class="a">
                              <input name="" type="text" class="input_email" />
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="user_one">
                        <div class="row">
                          <div class="span2">
                            <div class="email_txt_check"><span>*</span> City :</div>
                          </div>
                          <div class="span4">
                            <div class="a">
                              <input name="" type="text" class="input_email" />
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="user_one">
                        <div class="row">
                          <div class="span2">
                            <div class="email_txt_check"><span>*</span> Post Code :</div>
                          </div>
                          <div class="span4">
                            <div class="a">
                              <input name="" type="text" class="input_email" />
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="user_one">
                        <div class="row">
                          <div class="span2">
                            <div class="email_txt_check"><span>*</span> Country :</div>
                          </div>
                          <div class="span4">
                            <div class="a">
                              <div class="drop_bx">
                                <select class="select" title="Select one">
                                  <option selected="selected">Select Country</option>
                                  <option>India</option>
                                  <option>Brazil</option>
                                  <option>Korea</option>
                                  <option>Russia</option>
                                  <option>America</option>
                                </select>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="user_one">
                        <div class="row">
                          <div class="span2">
                            <div class="email_txt_check"><span>*</span> * Region / State :</div>
                          </div>
                          <div class="span4">
                            <div class="a">
                              <div class="drop_bx">
                                <select class="select" title="Select one">
                                  <option selected="selected"> --- Please Select --- </option>
                                  <option>Funafuti</option>
                                </select>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="clr"></div>
                      <div class="cont_bt"><a href="#">Continue <i class="fa fa-caret-right"></i></a></div>
                    </li>
                  </ul>
                </li>
                <li class='has-sub'><a href='#'><span>Step 4 : Delivery Method</span></a>
                  <ul>
                    <li>
                      <div class="check_select">Please select the preferred shipping method to use on this order.</div>
                      <div class="flat_head">Flat Rate</div>
                      <div class="radio_area" style="margin-bottom:30px;">
                        <input type="radio" name="radiog_lite" id="radio5" class="css-checkbox" />
                        <label for="radio5" class="css-label radGroup1">Flat Shipping Rate  £0.00</label>
                      </div>
                      <div class="flat_head">Add Comments About Your Order</div>
                      <div class="radio_area">
                        <textarea class="input_email" style="resize:none;" rows="4" cols="" name=""></textarea>
                      </div>
                      <div class="clr"></div>
                      <div class="cont_bt"><a href="#">Continue <i class="fa fa-caret-right"></i></a></div>
                    </li>
                  </ul>
                </li>
                <li class='has-sub'><a href='#'><span>Step 5 : Payment Method</span></a>
                  <ul>
                    <li>
                      <div class="check_select">Please select the preferred payment method to use on this order.</div>
                      <div class="radio_area">
                        <input type="radio" name="radiog_lite" id="radio6" class="css-checkbox" />
                        <label for="radio6" class="css-label radGroup1">Bank Transfer</label>
                      </div>
                      <div class="radio_area">
                        <input type="radio" name="radiog_lite" id="radio7" class="css-checkbox" />
                        <label for="radio7" class="css-label radGroup1">Credit or Debit Card (Processed securely by PayPal)</label>
                      </div>
                      <div class="radio_area">
                        <input type="radio" name="radiog_lite" id="radio8" class="css-checkbox" />
                        <label for="radio8" class="css-label radGroup1">PayPal</label>
                      </div>
                      <div class="flat_head">Add Comments About Your Order</div>
                      <div class="radio_area">
                        <textarea class="input_email" style="resize:none;" rows="4" cols="" name=""></textarea>
                      </div>
                      <div>
                        <input type="checkbox" class="css-checkbox" id="checkbox9">
                        <label class="css-label lite-red-check" name="checkbox2_lbl" for="checkbox9" style="font-size:13px; color:#8e8e8e;"> Please keep me updated about special offers and sales. </label>
                      </div>
                      <div class="clr"></div>
                      <div class="cont_bt"><a href="#">Continue <i class="fa fa-caret-right"></i></a></div>
                    </li>
                  </ul>
                </li>
                <li class='has-sub'><a href='#'><span>Step 6 : Confirm Order</span></a>
                  <ul>
                    <li>
                      <div class="table-responsive">
                        <table width="100%" border="0" cellspacing="0" cellpadding="0" class="table">
                          <tr class="cart_head">
                            <td class="img_bor">Product Name</td>
                            <td>Model</td>
                            <td>Quantity</td>
                            <td>Price</td>
                            <td>Total</td>
                          </tr>
                          <tr class="cart_row_one">
                            <td class="pic_bor">Alba Website</td>
                            <td class="pic_name">ALBA_02</td>
                            <td class="pic_name">1</td>
                            <td class="pic_prc">£498.00</td>
                            <td class="pic_prc">£498.00</td>
                          </tr>
                        </table>
                      </div>
                      <div class="order_summary_bx">
                        <div class="summary_content" style="margin-bottom:30px;">
                          <div class="summary_one">
                            <div class="summary_txt">Sub-Total:</div>
                            <div class="summary_qaunt">&pound; 498.00</div>
                            <div class="clr"></div>
                          </div>
                          <div class="summary_one">
                            <div class="summary_txt">Flat Shipping Rate</div>
                            <div class="summary_qaunt">&pound; 0.00</div>
                            <div class="clr"></div>
                          </div>
                          <div class="summary_one">
                            <div class="summary_txt">Free Home Delivery</div>
                            <div class="summary_qaunt">&pound; 50.00</div>
                            <div class="clr"></div>
                          </div>
                          <div class="sumary_total">
                            <div class="summary_total_l">Total</div>
                            <div class="summary_total_r">&pound; 1,097</div>
                            <div class="clr"></div>
                          </div>
                        </div>
                        <div class="clr"></div>
                      </div>
                      <div class="check_select">Bank Transfer Instructions</div>
                      <div class="back_inst"> Please transfer the total amount to the following bank account.<br />
                        Make your payment directly into our bank account. Please use your Order ID as the payment reference. Your order wont be shipped until the funds have cleared in our account.<br />
                        Your order will not ship until we receive payment. </div>
                      <div class="clr"></div>
                      <div class="cont_bt"><a href="#">Confirm Order <i class="fa fa-caret-right"></i></a></div>
                    </li>
                  </ul>
                </li>
                
                <!--<li class='last'><a href='#'><span>Contact</span></a></li>-->
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- content end--> 

<?php include BASE_PATH."include/footer.php" 
?>

</body>
</html>
