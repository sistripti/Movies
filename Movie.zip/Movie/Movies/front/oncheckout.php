<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>Antheia Flowers ::checkout::</title>

<!--main-css-->
<link href="css/antheia_flowers.css" rel="stylesheet" type="text/css" media="screen" />

<!--Bootstrap responsive-->
<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
<link href="css/bootstrap-responsive.min.css" rel="stylesheet" type="text/css" />

<!--font-awesome-css-start-here-->
<link href="css/font-awesome.css" rel="stylesheet" type="text/css" />
<link href="css/font-awesome.min.css" rel="stylesheet" type="text/css" />

<!--[if gte IE 8]>
	<link rel="stylesheet" type="text/css" href="css/ie8-and-up.css" />
<![endif]-->

<!--main-menu-->
<link href="css/main.css" rel="stylesheet" type="text/css" />
<link href="css/demo.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" language="javascript" src="js/jquery-1.8.2.js"></script>
<script type="text/javascript" language="javascript" src="js/flaunt.js"></script>
<link rel="stylesheet" href="css/accordion.css" />
<script type="text/javascript" language="javascript" src="js/script.js"></script>

<!--form-drop-arrow-->
<script type="text/javascript">
	$(document).ready(function(){	

		if (!$.browser.opera) {
    
			// select element styling
			$('select.select').each(function(){
				var title = $(this).attr('title');
				if( $('option:selected', this).val() != ''  ) title = $('option:selected',this).text();
				$(this)
					.css({'z-index':10,'opacity':0,'-khtml-appearance':'none'})
					.after('<span class="select">' + title + '</span>')
					.change(function(){
						val = $('option:selected',this).text();
						$(this).next().text(val);
						})
			});

		};
		
	});
</script>

<!--checkbox-radio-css-->
<link rel="stylesheet" href="css/style.css" type="text/css" />
</head>

<body>

<!--top bar start-->
<div class="top_bar_head">
  <div class="container">
    <div class="row">
      <div class="span12">
        <div class="row">
          <div class="span10">
            <div class="top_list">
              <ul>
                <li><a href="#"><i class="fa fa-user"></i>My Account</a></li>
                <li><a href="#"><i class="fa fa-heart"></i>My Wishlist</a></li>
                <li><a href="#"><i class="fa fa-check"></i>Checkout</a></li>
                <li><a href="#"><i class="fa fa-lock"></i>Log in</a></li>
              </ul>
            </div>
          </div>
          <div class="span2">
            <div class="top_item_bx"><img src="images/item.png" alt="item" /><a href="#">0 item(s)</a></div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!--top bar end--> 

<!--logo bar start-->
<div class="logo_bar_head">
  <div class="container">
    <div class="row">
      <div class="span12">
        <div class="row">
          <div class="span3">
            <div class="logo"><img src="images/logo.jpg" alt="logo" /></div>
          </div>
          <div class="span7">
            <div class="free_delivery"><a href="#"><img src="images/free_delivery.jpg" alt="free_delivery" /></a></div>
            <div class="serch_bx">
              <form class="custom" method="get" id="ajax_searchform" action="sweetdatewp">
                <div class="search_l">
                  <input type="text" value="" name="s" class="search_menu" placeholder="Enter your keyword..." />
                </div>
                <div class="search_button">
                  <button class="search_bt" id="search"><img src="images/search.png" alt="search" /></button>
                </div>
              </form>
            </div>
          </div>
          <div class="span2">
            <div class="top_socila">
              <ul>
                <li><a href="#"><img src="images/facebook.jpg" alt="facebook" /></a></li>
                <li><a href="#"><img src="images/twitter.jpg" alt="twitter" /></a></li>
                <li><a href="#"><img src="images/google.jpg" alt="google" /></a></li>
                <li><a href="#"><img src="images/in.jpg" alt="in" /></a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!--top bar end--> 

<!--main menu start-->
<div class="menu_head">
  <div class="container">
    <div class="row">
      <div class="span12">
        <div class="nav">
          <ul class="nav-list">
            <li class="nav-item"><a href="#" class="act">Home</a></li>
            <li class="nav-item"><a href="#">Shop By Type</a>
              <ul class="nav-submenu">
                <li class="nav-submenu-item"> <a href="?=submenu-1">The Institution</a> </li>
                <li class="nav-submenu-item"> <a href="?=submenu-2">NMC Activities</a> </li>
                <li class="nav-submenu-item"> <a href="?=submenu-3">Board Members</a> </li>
                <li class="nav-submenu-item"> <a href="?=submenu-4">Advisory Board4</a> </li>
                <li class="nav-submenu-item"> <a href="?=submenu-5">Teachers</a> </li>
              </ul>
            </li>
            <li class="nav-item"><a href="#">Price</a></li>
            <li class="nav-item"><a href="#">Occasions</a></li>
            <li class="nav-item"><a href="#">Gifts Collection</a></li>
            <li class="nav-item"><a href="#">Birthdays</a></li>
            <li class="nav-item"><a href="#">Specialities</a></li>
            <li class="nav-item"><a href="#">Blogs</a></li>
            <li class="nav-item"><a href="#" class="last">Contact Us</a></li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- main menu end--> 

<!--content start-->
<div class="container">
  <div class="row">
    <div class="span12">
      <div class="middle_content">
        <div class="row">
          <div class="span3">
            <div class="side-menu">
              <div class="side-menu-title">
                <h3>Product Categories
                  <div class="side-menu-spach"></div>
                </h3>
              </div>
              <div id="menusidebar">
                <ul>
                  <li><a href="#">Shop By Type</a></li>
                  <li><a href="#">Price</a></li>
                  <li><a href="#">Gifts Collection</a></li>
                  <li><a href="#">Birthdays</a></li>
                  <li><a href="#">Specialities</a></li>
                </ul>
              </div>
              <div class="clr"></div>
            </div>
            <div class="special_min">
              <div class="spec_title">Specials</div>
              <div class="specl_box">
                <div class="spec_img"><img src="images/bestseller1.jpg" alt="Special img" width="80" /></div>
                <div class="spec_sub_title"><a href="#">Raspberry Orchid</a></div>
                <div class="spec_price">$100<span>$150</span></div>
                <div class="clr"></div>
              </div>
              <div class="specl_box">
                <div class="spec_img"><img src="images/bestseller1.jpg" alt="Special img" width="80" /></div>
                <div class="spec_sub_title"><a href="#">Raspberry Orchid</a></div>
                <div class="spec_price">$100<span>$150</span></div>
                <div class="clr"></div>
              </div>
              <div class="specl_box">
                <div class="spec_img"><img src="images/bestseller1.jpg" alt="Special img" width="80" /></div>
                <div class="spec_sub_title"><a href="#">Raspberry Orchid</a></div>
                <div class="spec_price">$100<span>$150</span></div>
                <div class="clr"></div>
              </div>
            </div>
            <div class="special_min">
              <div class="spec_title">Bestsellers</div>
              <div class="raspberry_orchid_bx"> <img src="images/raspberry_orchid.jpg" alt="raspberry orchid" />
                <div class="raspberry_titl"><a href="#">Raspberry Orchid</a></div>
                <div class="raspberry_price">34.99 AED</div>
              </div>
            </div>
          </div>
          
          <div class="span9">
            <div class="head_area">
              <div class="related_prod">Checkout</div>
              <div class="prod_bor"></div>
            </div>
            <div id='cssmenu'>
              <ul>
                <li><a href='#'><span>Step 1 : Checkout Option</span></a></li>
                <li class='has-sub active'><a href='#'><span>Step 2 : Billing Details</span></a>
                  <ul>
                    <li>
                      <div class="radio_area">
                        <input type="radio" name="radiog_lite" id="radio1" class="css-checkbox" />
                        <label for="radio1" class="css-label radGroup1">I want to use an existing address</label>
                      </div>
                      <div class="radio_area">
                        <textarea name="" cols="" rows="4" style="resize:none;" class="input_email"></textarea>
                      </div>
                      <div class="radio_area">
                        <input type="radio" name="radiog_lite" id="radio2" class="css-checkbox" />
                        <label for="radio2" class="css-label radGroup1">I want to use a new address</label>
                      </div>
                      <div class="user_one">
                        <div class="row">
                          <div class="span2">
                            <div class="email_txt_check"><span>*</span> First Name :</div>
                          </div>
                          <div class="span4">
                            <div class="a">
                              <input name="" type="text" class="input_email" />
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="user_one">
                        <div class="row">
                          <div class="span2">
                            <div class="email_txt_check"><span>*</span> Last Name :</div>
                          </div>
                          <div class="span4">
                            <div class="a">
                              <input name="" type="text" class="input_email" />
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="user_one">
                        <div class="row">
                          <div class="span2">
                            <div class="email_txt_check"><span>*</span> Company :</div>
                          </div>
                          <div class="span4">
                            <div class="a">
                              <input name="" type="text" class="input_email" />
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="user_one">
                        <div class="row">
                          <div class="span2">
                            <div class="email_txt_check"><span>*</span> Address 1 :</div>
                          </div>
                          <div class="span4">
                            <div class="a">
                              <input name="" type="text" class="input_email" />
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="user_one">
                        <div class="row">
                          <div class="span2">
                            <div class="email_txt_check"><span>*</span> Address 2 :</div>
                          </div>
                          <div class="span4">
                            <div class="a">
                              <input name="" type="text" class="input_email" />
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="user_one">
                        <div class="row">
                          <div class="span2">
                            <div class="email_txt_check"><span>*</span> City :</div>
                          </div>
                          <div class="span4">
                            <div class="a">
                              <input name="" type="text" class="input_email" />
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="user_one">
                        <div class="row">
                          <div class="span2">
                            <div class="email_txt_check"><span>*</span> Post Code :</div>
                          </div>
                          <div class="span4">
                            <div class="a">
                              <input name="" type="text" class="input_email" />
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="user_one">
                        <div class="row">
                          <div class="span2">
                            <div class="email_txt_check"><span>*</span> Country :</div>
                          </div>
                          <div class="span4">
                            <div class="a">
                              <div class="drop_bx">
                                <select class="select" title="Select one">
                                  <option selected="selected">Select Country</option>
                                  <option>India</option>
                                  <option>Brazil</option>
                                  <option>Korea</option>
                                  <option>Russia</option>
                                  <option>America</option>
                                </select>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="user_one">
                        <div class="row">
                          <div class="span2">
                            <div class="email_txt_check"><span>*</span> * Region / State :</div>
                          </div>
                          <div class="span4">
                            <div class="a">
                              <div class="drop_bx">
                                <select class="select" title="Select one">
                                  <option selected="selected"> --- Please Select --- </option>
                                  <option>Funafuti</option>
                                </select>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="clr"></div>
                      <div class="cont_bt"><a href="#">Continue <i class="fa fa-caret-right"></i></a></div>
                    </li>
                  </ul>
                </li>
                <li class='has-sub'><a href='#'><span>Step 3 : Delivery Details</span></a>
                  <ul>
                    <li>
                      <div class="radio_area">
                        <input type="radio" name="radiog_lite" id="radio3" class="css-checkbox" />
                        <label for="radio3" class="css-label radGroup1">I want to use an existing address</label>
                      </div>
                      <div class="radio_area">
                        <textarea name="" cols="" rows="4" style="resize:none;" class="input_email"></textarea>
                      </div>
                      <div class="radio_area">
                        <input type="radio" name="radiog_lite" id="radio4" class="css-checkbox" />
                        <label for="radio4" class="css-label radGroup1">I want to use a new address</label>
                      </div>
                      <div class="user_one">
                        <div class="row">
                          <div class="span2">
                            <div class="email_txt_check"><span>*</span> First Name :</div>
                          </div>
                          <div class="span4">
                            <div class="a">
                              <input name="" type="text" class="input_email" />
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="user_one">
                        <div class="row">
                          <div class="span2">
                            <div class="email_txt_check"><span>*</span> Last Name :</div>
                          </div>
                          <div class="span4">
                            <div class="a">
                              <input name="" type="text" class="input_email" />
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="user_one">
                        <div class="row">
                          <div class="span2">
                            <div class="email_txt_check"><span>*</span> Company :</div>
                          </div>
                          <div class="span4">
                            <div class="a">
                              <input name="" type="text" class="input_email" />
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="user_one">
                        <div class="row">
                          <div class="span2">
                            <div class="email_txt_check"><span>*</span> Address 1 :</div>
                          </div>
                          <div class="span4">
                            <div class="a">
                              <input name="" type="text" class="input_email" />
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="user_one">
                        <div class="row">
                          <div class="span2">
                            <div class="email_txt_check"><span>*</span> Address 2 :</div>
                          </div>
                          <div class="span4">
                            <div class="a">
                              <input name="" type="text" class="input_email" />
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="user_one">
                        <div class="row">
                          <div class="span2">
                            <div class="email_txt_check"><span>*</span> City :</div>
                          </div>
                          <div class="span4">
                            <div class="a">
                              <input name="" type="text" class="input_email" />
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="user_one">
                        <div class="row">
                          <div class="span2">
                            <div class="email_txt_check"><span>*</span> Post Code :</div>
                          </div>
                          <div class="span4">
                            <div class="a">
                              <input name="" type="text" class="input_email" />
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="user_one">
                        <div class="row">
                          <div class="span2">
                            <div class="email_txt_check"><span>*</span> Country :</div>
                          </div>
                          <div class="span4">
                            <div class="a">
                              <div class="drop_bx">
                                <select class="select" title="Select one">
                                  <option selected="selected">Select Country</option>
                                  <option>India</option>
                                  <option>Brazil</option>
                                  <option>Korea</option>
                                  <option>Russia</option>
                                  <option>America</option>
                                </select>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="user_one">
                        <div class="row">
                          <div class="span2">
                            <div class="email_txt_check"><span>*</span> * Region / State :</div>
                          </div>
                          <div class="span4">
                            <div class="a">
                              <div class="drop_bx">
                                <select class="select" title="Select one">
                                  <option selected="selected"> --- Please Select --- </option>
                                  <option>Funafuti</option>
                                </select>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="clr"></div>
                      <div class="cont_bt"><a href="#">Continue <i class="fa fa-caret-right"></i></a></div>
                    </li>
                  </ul>
                </li>
                <li class='has-sub'><a href='#'><span>Step 4 : Delivery Method</span></a>
                  <ul>
                    <li>
                      <div class="check_select">Please select the preferred shipping method to use on this order.</div>
                      <div class="flat_head">Flat Rate</div>
                      <div class="radio_area" style="margin-bottom:30px;">
                        <input type="radio" name="radiog_lite" id="radio5" class="css-checkbox" />
                        <label for="radio5" class="css-label radGroup1">Flat Shipping Rate 	£0.00</label>
                      </div>
                      <div class="flat_head">Add Comments About Your Order</div>
                      <div class="radio_area">
                        <textarea class="input_email" style="resize:none;" rows="4" cols="" name=""></textarea>
                      </div>
                      <div class="clr"></div>
                      <div class="cont_bt"><a href="#">Continue <i class="fa fa-caret-right"></i></a></div>
                    </li>
                  </ul>
                </li>
                <li class='has-sub'><a href='#'><span>Step 5 : Payment Method</span></a>
                  <ul>
                    <li>
                      <div class="check_select">Please select the preferred payment method to use on this order.</div>
                      <div class="radio_area">
                        <input type="radio" name="radiog_lite" id="radio6" class="css-checkbox" />
                        <label for="radio6" class="css-label radGroup1">Bank Transfer</label>
                      </div>
                      <div class="radio_area">
                        <input type="radio" name="radiog_lite" id="radio7" class="css-checkbox" />
                        <label for="radio7" class="css-label radGroup1">Credit or Debit Card (Processed securely by PayPal)</label>
                      </div>
                      <div class="radio_area">
                        <input type="radio" name="radiog_lite" id="radio8" class="css-checkbox" />
                        <label for="radio8" class="css-label radGroup1">PayPal</label>
                      </div>
                      <div class="flat_head">Add Comments About Your Order</div>
                      <div class="radio_area">
                        <textarea class="input_email" style="resize:none;" rows="4" cols="" name=""></textarea>
                      </div>
                      <div>
                        <input type="checkbox" class="css-checkbox" id="checkbox9">
                        <label class="css-label lite-red-check" name="checkbox2_lbl" for="checkbox9" style="font-size:13px; color:#8e8e8e;"> Please keep me updated about special offers and sales. </label>
                      </div>
                      <div class="clr"></div>
                      <div class="cont_bt"><a href="#">Continue <i class="fa fa-caret-right"></i></a></div>
                    </li>
                  </ul>
                </li>
                <li class='has-sub'><a href='#'><span>Step 6 : Confirm Order</span></a>
                  <ul>
                    <li>
                      <div class="table-responsive">
                        <table width="100%" border="0" cellspacing="0" cellpadding="0" class="table">
                          <tr class="cart_head">
                            <td class="img_bor">Product Name</td>
                            <td>Model</td>
                            <td>Quantity</td>
                            <td>Price</td>
                            <td>Total</td>
                          </tr>
                          <tr class="cart_row_one">
                            <td class="pic_bor">Alba Website</td>
                            <td class="pic_name">ALBA_02</td>
                            <td class="pic_name">1</td>
                            <td class="pic_prc">£498.00</td>
                            <td class="pic_prc">£498.00</td>
                          </tr>
                        </table>
                      </div>
                      <div class="order_summary_bx">
                        <div class="summary_content" style="margin-bottom:30px;">
                          <div class="summary_one">
                            <div class="summary_txt">Sub-Total:</div>
                            <div class="summary_qaunt">&pound; 498.00</div>
                            <div class="clr"></div>
                          </div>
                          <div class="summary_one">
                            <div class="summary_txt">Flat Shipping Rate</div>
                            <div class="summary_qaunt">&pound; 0.00</div>
                            <div class="clr"></div>
                          </div>
                          <div class="summary_one">
                            <div class="summary_txt">Free Home Delivery</div>
                            <div class="summary_qaunt">&pound; 50.00</div>
                            <div class="clr"></div>
                          </div>
                          <div class="sumary_total">
                            <div class="summary_total_l">Total</div>
                            <div class="summary_total_r">&pound; 1,097</div>
                            <div class="clr"></div>
                          </div>
                        </div>
                        <div class="clr"></div>
                      </div>
                      <div class="check_select">Bank Transfer Instructions</div>
                      <div class="back_inst"> Please transfer the total amount to the following bank account.<br />
                        Make your payment directly into our bank account. Please use your Order ID as the payment reference. Your order wont be shipped until the funds have cleared in our account.<br />
                        Your order will not ship until we receive payment. </div>
                      <div class="clr"></div>
                      <div class="cont_bt"><a href="#">Confirm Order <i class="fa fa-caret-right"></i></a></div>
                    </li>
                  </ul>
                </li>
                
                <!--<li class='last'><a href='#'><span>Contact</span></a></li>-->
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- content end--> 

<!--footer start-->
<div class="footer_links">
  <div class="container">
    <div class="row">
      <div class="span12">
        <div class="row">
          <div class="span3">
            <div class="footer_heading">About US</div>
            <div class="heading_bor"></div>
            <div class="menu_name">
              <ul>
                <li><a href="#"><i class="fa fa-caret-right"></i>About Us</a></li>
                <li><a href="#"><i class="fa fa-caret-right"></i>Antheia Flowers Stories</a></li>
                <li><a href="#"><i class="fa fa-caret-right"></i>Our Press</a></li>
                <li><a href="#"><i class="fa fa-caret-right"></i>Terms &amp; Conditions</a></li>
                <li><a href="#"><i class="fa fa-caret-right"></i>Privacy Policy</a></li>
                <li><a href="#"><i class="fa fa-caret-right"></i>Sitemap</a></li>
              </ul>
            </div>
          </div>
          <div class="span3">
            <div class="footer_heading">Customer Service</div>
            <div class="heading_bor"></div>
            <div class="menu_name">
              <ul>
                <li><a href="#"><i class="fa fa-caret-right"></i>Contact Us</a></li>
                <li><a href="#"><i class="fa fa-caret-right"></i>Customer service</a></li>
                <li><a href="#"><i class="fa fa-caret-right"></i>Privacy policy</a></li>
                <li><a href="#"><i class="fa fa-caret-right"></i>FAQ's</a></li>
                <li><a href="#"><i class="fa fa-caret-right"></i>My Account (Log In)</a></li>
              </ul>
            </div>
          </div>
          <div class="span3">
            <div class="footer_heading">Our Products</div>
            <div class="heading_bor"></div>
            <div class="menu_name">
              <ul>
                <li><a href="#"><i class="fa fa-caret-right"></i>How to apply &amp; Tips</a></li>
                <li><a href="#"><i class="fa fa-caret-right"></i>Sample Request</a></li>
                <li><a href="#"><i class="fa fa-caret-right"></i>Product Features</a></li>
                <li><a href="#"><i class="fa fa-caret-right"></i>Customer Stories</a></li>
              </ul>
            </div>
          </div>
          <div class="span3">
            <div class="footer_heading">Newsletter Sing Up</div>
            <div class="heading_bor"></div>
            <div class="menu_name">
              <input name="" type="text" class="frm_newsletter" placeholder="Enter your E-mail address " />
              <div class="bt_newsletter">
                <input name="" type="button" value="Subscribe" class="btn_news" />
              </div>
              <div class="footer_social">
                <ul>
                  <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                  <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                  <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                  <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- Footer end-->

<div class="footer_copyright">
  <div class="container">
    <div class="row">
      <div class="span12">
        <div class="footer_copy_main">
          <div class="copyright_l">&copy; 2015 Antheia Flowers Ltd. All Rights Reserved.</div>
          <div class="copyright_r">
            <ul>
              <li>We Accept These Cards :</li>
              <li><a href="#"><img src="images/payment_1.jpg" alt="payment_1" /></a></li>
              <li><a href="#"><img src="images/payment_2.jpg" alt="payment_2" /></a></li>
              <li><a href="#"><img src="images/payment_3.jpg" alt="payment_3" /></a></li>
              <li><a href="#"><img src="images/payment_4.jpg" alt="payment_4" /></a></li>
              <li><a href="#"><img src="images/payment_5.jpg" alt="payment_5" /></a></li>
            </ul>
          </div>
        </div>
        <div class="clr"></div>
      </div>
    </div>
  </div>
</div>

<!-- Bootstrap responsive --> 
<script type="text/javascript" language="javascript" src="js/bootstrap.min.js"></script> 
<!-- Bootstrap responsive -->
</body>
</html>
