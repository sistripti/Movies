<?php 
include "/opt/lampp/htdocs/Soham/SarikaHomeAppliances/anthiaflower/front/include/connect.php";
session_start();

if(isset($_POST['Signup']))
{
	$Hobbies =""; 
	if(isset($_POST['First_Name'])){ $First_Name = $_POST['First_Name']; } else { $First_Name = ""; }
	if(isset($_POST['Last_Name'])) { $Last_Name = $_POST['Last_Name']; } else{ $Last_Name = ""; }
	if(isset($_POST['Email_Id'])){ $Email_Id= $_POST['Email_Id']; } else { $Email_Id=""; }
	if(isset($_POST['Password'])) { $Password=$_POST['Password']; } else { $Password=""; }

	$sql = "SELECT count(*) as `total` from `tbl_user_registration` WHERE `email_id` = '".$Email_Id."'";
	$result=mysqli_query($conn,$sql);
	$data=mysqli_fetch_assoc($result);
	if($data['total'] > 0)
	{
		$_SESSION['error'] = "Email already exist.";
		header('Refresh: 0; url=user_registration.php');
	}
	else
	{

		$sql1 = "INSERT INTO `tbl_user_registration`(`first_name`,
		`last_name`,
		`email_id`,
		`password`)
		VALUES ('".$First_Name."',
		'".$Last_Name."',
		'".$Email_Id."',
		'".$Password."')";

		$res1 = mysqli_query($conn,$sql1);

		if($res1){
			$_SESSION['success'] = "Data has been store successfully";
			header('Refresh: 0; url=user_registration.php');
		}
		else
		{
			$_SESSION['error'] = "Something went wrong";
			header('Refresh: 0; url=user_registration.php');
		}   
	}
}
?>