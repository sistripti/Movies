<?php
include "/opt/lampp/htdocs/Soham/SarikaHomeAppliances/anthiaflower/admin/include/connect.php";
session_start();
if(isset($_POST['Edit']))
{
	if(isset($_POST['Category_Name'])){ $Category_Name = $_POST['Category_Name']; } else { $Category_Name = ""; }

	if(isset($_POST['Category_Id'])){ $Category_Id = $_POST['Category_Id']; } else { $Category_Id = ""; }
  
	$sql ="UPDATE `tbl_category` SET `category_name` = '".$Category_Name."' WHERE `id` = ".base64_decode($Category_Id)."";
	$result = mysqli_query($conn,$sql) or die('Error querying database.');
	mysqli_close($conn);
	$_SESSION['success'] = "Product updated successfully";
    header('Refresh: 0; url=manage.php');
	
};
?>
