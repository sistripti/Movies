<?php 
	include "connect.php";
	$row = [];
	$sql = "SELECT * FROM category";
	$result = mysqli_query($conn,$sql);
?>
<!DOCTYPE html>
<html>
<head>
	<title>Category</title>
</head>
<body>
	<h2>Category</h2>
	<?php
	echo '<table border="1">';
    echo '<tr><th>Id</th><th>Category Name</th><th>Created Date</th></tr>';
    while ($row = mysqli_fetch_array($result)) {
      echo '<tr>
      			<td>'.$row['id'].'</td>
      			<td>'.$row['name'].'</td>
      			<td>'.date('d/m/Y', strtotime($row['created_at'])).'</td>
      		</tr>';
   }
   echo "</table>";
	?>
</body>
</html>